import { ApiResponse } from "@/types/general_types";

export const DynamicRouter = (
  service: string,
  endpoint: string,
  params?: Record<string, any>,
  trailingSlash: boolean = true
) => {
  let url = `${process.env.NEXT_PUBLIC_API_URL}/${service}/${endpoint}`;
  if (trailingSlash) {
    url += "/";
  }
  if (params) {
    const queryString = Object.entries(params)
      .map(
        ([key, value]) =>
          `${encodeURIComponent(key)}=${encodeURIComponent(value)}`
      )
      .join("&");
    url += `?${queryString}`;
  }
  return url;
};

export const postRequest = async (url: string, params?: { arg?: any }) => {
  return makeRequest("POST", url, params?.arg);
};

export const putRequest = async (url: string, params?: { arg?: any }) => {
  return makeRequest("PUT", url, params?.arg);
};

export const deleteRequest = async (url: string) => {
  try {
    const response = await fetch(url, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      credentials: "include",
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    try {
      const jsonResponse = await response.json();
      return jsonResponse;
    } catch (e) {
      return {
        statusCode: 200,
        status: "success",
        message: "Record deleted successfully",
      };
    }
  } catch (error: any) {
    return {
      statusCode: 500,
      status: "error",
      message: error?.message || "An error occurred while deleting",
    };
  }
};

export const makeRequest = async (method: string, url: string, data?: any) => {
  try {
    console.log(
      `[${method}] Request to URL: ${url}`,
      data ? `Payload: ${JSON.stringify(data)}` : "No payload"
    );

    const response = await fetch(url, {
      method,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include",
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`[${method}] Error Response:`, errorText);
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const contentType = response.headers.get("content-type");
    if (contentType && contentType.indexOf("application/json") !== -1) {
      const jsonResponse = await response.json();
      console.log(`[${method}] Success Response:`, jsonResponse);
      return jsonResponse;
    } else if (method === "DELETE") {
      console.log(`[${method}] Success Response: Record deleted successfully`);
      return {
        statusCode: 200,
        status: "success",
        message: "Record deleted successfully",
      };
    }

    throw new Error("Invalid response format");
  } catch (error: any) {
    console.error(`[${method}] Request Error:`, error);
    throw error;
  }
};

// Generic fetcher function
export async function fetcher<T>(url: string): Promise<ApiResponse<T>> {
  const res = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
    },
    credentials: "include",
  });

  if (!res.ok) {
    throw new Error("An error occurred while fetching the data.");
  }

  const response: ApiResponse<T> = await res.json();
  return response;
}
