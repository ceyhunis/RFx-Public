import emailjs from "@emailjs/browser";

// Fetcher fonksiyonunu ekleyelim
export const fetcher = async (url: string) => {
  if (!url) {
    console.warn("No URL provided to fetcher");
    return null;
  }

  try {
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();

    // API yanıtının yapısını kontrol edelim
    if (!data || typeof data !== "object") {
      return null;
    }

    return data;
  } catch (error) {
    throw error;
  }
};

export const DynamicRouter = (path: string, key: string, params?: any) => {
  // Base URL
  //@ts-ignore
  const baseUrl = `${process.env.NEXT_PUBLIC_API_URL}${path}/${key}/`;

  // Check if params is provided and is an object
  if (params && typeof params === "object") {
    // Create an instance of URLSearchParams
    const searchParams = new URLSearchParams();

    // Loop through the params object and append each key-value pair
    Object.keys(params).forEach((key) => {
      searchParams.append(key, params[key]);
    });

    // Append the query string to the baseUrl
    return `${baseUrl}?${searchParams.toString()}`;
  }

  return baseUrl;
};

export const deleteRequest = async (key: string, { arg }: { arg: any }) => {
  return makeRequest("DELETE", key, { arg });
};

export const putRequest = async (key: string, { arg }: { arg: any }) => {
  return makeRequest("PUT", key, { arg });
};

export const postRequest = async (key: string, { arg }: { arg: any }) => {
  const result = await makeRequest("POST", key, { arg });
  return result;
};

export const makeRequest = async (
  method: string,
  url: string,
  { arg }: any
) => {
  try {
    // Remove any double slashes (except after http:// or https://)
    const cleanUrl = url.replace(/([^:]\/)\/+/g, "$1");
    console.log(`Making ${method} request to:`, cleanUrl);

    const response = await fetch(cleanUrl, {
      method: method,
      headers: {
        "Content-Type": "application/json",
      },
      body: method !== "DELETE" ? JSON.stringify(arg) : undefined,
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`${method} Error Response:`, errorText);
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    console.log(`${method} Response Data:`, data);
    return data;
  } catch (error) {
    console.error(`${method} Request Error:`, error);
    throw error;
  }
};

// Add new utility functions for functional areas
export const functionalAreaRequests = {
  delete: async (url: string, id: number) => {
    const deleteUrl = `${url}${id}/`;
    return makeRequest("DELETE", deleteUrl, { arg: {} });
  },

  update: async (url: string, id: number, data: any) => {
    const updateUrl = `${url}${id}/`;
    return makeRequest("PUT", updateUrl, { arg: data });
  },

  create: async (url: string, data: any) => {
    return makeRequest("POST", url, { arg: data });
  },
};

export const sendEmail: any = async (params: any) => {
  const result = emailjs
    .send("service_v6lszsh", "template_p6a14j5", params, "x9zeAUQZ8kjXvljQX")
    .then(
      function (response) {
        return { status: response.status, text: response.text };
      },
      function (error) {
        return error;
      }
    );
  return result;
};
