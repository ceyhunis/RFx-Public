import NextAuth, { User } from "next-auth";
import credentials from "next-auth/providers/credentials";
import { DynamicRouter } from "./utils/request_utils";

export const { handlers, signIn, signOut, auth } = NextAuth({
  providers: [
    credentials({
      credentials: {
        email: {},
        password: {},
      },

      authorize: async (credentials) => {
        let user;

        const getUserFromDb = async (
          email: string | undefined | unknown,
          password: string | undefined | unknown
        ) => {
          const url = DynamicRouter("auth", "authenticate");
          const result = await fetch(url, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              email: email,
              password: password,
            }),
          });

          return result.json();
        };

        user = await getUserFromDb(credentials.email, credentials.password);
        const userData: User = user?.data[0];
     

        if (!userData?.id) {
          throw new Error("Invalid credentials.");
        }

        return userData;
      },
    }),
  ],
  jwt: {
    maxAge: 60 * 60 * 24 * 30,
  },
  session: {
    strategy: "jwt",
  },
  trustHost: true,

  callbacks: {
    async signIn({ user, account, profile, email, credentials }) {
      return true;
    },
    async redirect({ url, baseUrl }) {
      if (url.startsWith("/")) return `${baseUrl}${url}`;
      else if (new URL(url).origin === baseUrl) return url;
      return baseUrl;
    },
    async session({ session, user, token }) {
      //@ts-expect-error
      const tuser: User = token?.user;
      //@ts-expect-error
      session.user = tuser;
      return session;
    },
    async jwt({ token, user }) {
      if (user) {
        token.user = user;
      }
      return Promise.resolve(token);
    },
  },
  pages: {
    signIn: "/",
    error: "/",
    signOut: "/",
  },
});
