"use client";
import { DynamicRouter } from "@/utils/request_utils";
import { useSearchParams } from "next/navigation";
import { useState } from "react";
import { Alert, Form, Button, Input, message } from "antd";

export default function RegisterPage() {
  const searchParams = useSearchParams();
  const [error, setError] = useState<string | null>(null);

  const token = searchParams.get("token")?.trim();
  const invitationEmail = searchParams.get("email")?.trim(); // Get invitation email from URL

  const handleSubmit = async (values: {
    first_name: string;
    last_name: string;
    email: string;
    password: string;
  }) => {
    if (!token || !invitationEmail) {
      setError("Invalid or missing invitation token or email");
      return;
    }

    try {
      console.log("Registration request details:", {
        registrationEmail: values.email,
        invitationEmail,
        token,
      });

      const registerUrl = DynamicRouter("auth", "invite-register");
      const registerResponse = await fetch(registerUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...values,
          username: values.email,
          invitation_email: invitationEmail, // Add invitation email
          token: token,
        }),
      });

      const registerResult = await registerResponse.json();
      console.log("Registration response:", registerResult);

      if (registerResponse.ok) {
        message.success("Registration successful! You can now log in.");
      } else {
        setError(registerResult.message || "Registration failed.");
      }
    } catch (error) {
      console.error("Error during registration:", error);
      setError("An unexpected error occurred during registration.");
    }
  };

  if (error) {
    return (
      <div style={{ padding: "20px" }}>
        <Alert
          message="Registration Error"
          description={`${error}.`}
          type="error"
          showIcon
        />
      </div>
    );
  }

  return (
    <div style={{ padding: "20px" }}>
      <Form onFinish={handleSubmit} layout="vertical">
        <Form.Item
          label="First Name"
          name="first_name"
          rules={[{ required: true, message: "Please input your first name!" }]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Last Name"
          name="last_name"
          rules={[{ required: true, message: "Please input your last name!" }]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Email"
          name="email"
          rules={[
            { required: true, message: "Please input your email!" },
            { type: "email", message: "Please enter a valid email!" },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Password"
          name="password"
          rules={[{ required: true, message: "Please input your password!" }]}
        >
          <Input.Password autoComplete="current-password" />
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Register
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
}
