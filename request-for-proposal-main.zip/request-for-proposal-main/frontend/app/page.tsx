"use client";

import MainFooter from "@/components/components/general/MainFooter";
import MainNavbar from "@/components/components/general/MainNavbar";
import LoginHero from "@/components/components/login-page/LoginHero";
import { notify } from "@/utils/functions_utils";
import { useSession } from "next-auth/react";
import { useSearchParams } from "next/navigation";
import { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const { data: session } = useSession();
  const error = params.get("error");
  useEffect(() => {
    if (error) {
      notify("Invalid email or password.", "error");
    }
    if (session) {
      router.push("/panel");
    }
  }, [error, session]);

  return (
    <>
      {" "}
      <MainNavbar />
      <LoginHero />
      <MainFooter />
    </>
  );
}
