"use client";
import { Card, Typography, Progress, Tag } from "antd";
import {
  CalendarOutlined,
  UsergroupAddOutlined,
  FileTextOutlined,
} from "@ant-design/icons";
import { useRouter } from "next/navigation";
import dayjs from "dayjs";

const { Title, Text } = Typography;

interface RFXCardProps {
  item: {
    id: number;
    rfp_name: string;
    rfp_description: string;
    created_at: string;
    services: number[];
    company_url: string;
    value_propositions: string;
  };
}

// Demo supplier progress since it's not in the backend data
const demoSupplierProgress = [
  { name: "Supplier A", progress: 75 },
  { name: "Supplier B", progress: 45 },
];

const RFXCard: React.FC<RFXCardProps> = ({ item }) => {
  const router = useRouter();
  const formatDate = (dateString: string) =>
    dayjs(dateString).format("DD MMM YY");

  return (
    <Card
      hoverable
      style={{
        width: "100%",
        maxWidth: "400px",
        minWidth: "280px",
        height: "auto",
        minHeight: "350px",
        margin: "10px",
        borderRadius: "8px",
        boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
        transition: "all 0.3s ease",
      }}
      onClick={() => router.push(`/panel/rfx/${item.id}`)}
      onMouseEnter={(e) => {
        const target = e.currentTarget;
        target.style.transform = "translateY(-5px)";
        target.style.boxShadow = "0 4px 20px rgba(0, 0, 0, 0.3)";
      }}
      onMouseLeave={(e) => {
        const target = e.currentTarget;
        target.style.transform = "translateY(0)";
        target.style.boxShadow = "0 2px 8px rgba(0, 0, 0, 0.1)";
      }}
    >
      {/* Title and Status */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <FileTextOutlined style={{ fontSize: "18px", color: "#3B82F6" }} />
          <Title level={5} style={{ margin: 0 }}>
            {item.rfp_name}
          </Title>
        </div>
        <Tag color="green">Active</Tag>
      </div>

      {/* Description */}
      <Text type="secondary" style={{ display: "block", marginTop: "8px" }}>
        {item.rfp_description}
      </Text>

      {/* Date and Services */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "16px",
          marginTop: "8px",
        }}
      >
        <Text>
          <CalendarOutlined style={{ marginRight: "4px" }} />
          Created: {formatDate(item.created_at)}
        </Text>
        <Text>
          <UsergroupAddOutlined style={{ marginRight: "4px" }} />
          {item.services.length} Services
        </Text>
      </div>

      <hr style={{ margin: "12px 0", borderColor: "#f0f0f0" }} />

      {/* Supplier Progress (Demo Data) */}
      <Text strong style={{ fontSize: "12px", color: "#8c8c8c" }}>
        SUPPLIER PROGRESS
      </Text>
      {demoSupplierProgress.map((supplier, index) => (
        <div key={index} style={{ marginTop: "8px" }}>
          <Text>{supplier.name}</Text>
          <Progress percent={supplier.progress} strokeColor="#3B82F6" />
        </div>
      ))}
    </Card>
  );
};

export default RFXCard;
