"use client";

import { DynamicRouter, postRequest } from "@/utils/request_utils";
import {
  RobotOutlined,
  SendOutlined,
  UserOutlined,
  ExportOutlined,
  LoadingOutlined,
  InfoCircleOutlined,
  BulbOutlined,
} from "@ant-design/icons";
import {
  Avatar,
  Button,
  Collapse,
  Input,
  Layout,
  List,
  Spin,
  message,
  Tooltip,
  Typography,
  Badge,
  Divider,
  Card,
  Tag,
} from "antd";
import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import useSWRMutation from "swr/mutation";

const { Header, Content, Footer } = Layout;
const { Text, Title, Paragraph } = Typography;

interface Message {
  id: string;
  content: string;
  isUser: boolean;
  rfpSections?: Record<string, string>;
  timestamp?: Date;
}

interface ChatBotProps {
  setDisplayedFunctionalAreas: (areas: any) => void;
  displayedFunctionalAreas: any;
  selectedCycle: any;
  updateTableWithAIData: (aiGeneratedData: any[]) => void;
}

const ChatBot = forwardRef(
  (
    {
      setDisplayedFunctionalAreas,
      displayedFunctionalAreas,
      selectedCycle,
      updateTableWithAIData,
    }: ChatBotProps,
    ref
  ) => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState("");
    const url = DynamicRouter("project", "chat");
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const [messageGPT, setMessageGPT] = useState("");
    const { trigger, isMutating } = useSWRMutation(url, postRequest);
    const [extractableAreas, setExtractableAreas] = useState<number>(0);
    const inputRef = useRef<any>(null);

    useImperativeHandle(ref, () => ({
      requestAIData: (cycle: any) => {
        handleCycleChange(cycle);
      },
      extractAndUpdateFunctionalAreas: () => {
        const functionalAreas = extractFunctionalAreas(messageGPT);
        if (functionalAreas.length > 0) {
          const mergedAreas = mergeWithExistingAreas(functionalAreas);
          updateTableWithAIData(mergedAreas);
          setDisplayedFunctionalAreas(mergedAreas);
        }
        return functionalAreas;
      },
    }));

    const scrollToBottom = () => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
      scrollToBottom();
    }, [messages]);

    useEffect(() => {
      if (messages.length === 0) {
        setMessages([
          {
            id: "welcome",
            content: `Hello! I'm your AI assistant. I can help you generate functional areas for ${
              selectedCycle?.name || "your business cycle"
            }. Just ask me or type "extract" to process my last response.`,
            isUser: false,
            timestamp: new Date(),
          },
        ]);
      }
    }, [selectedCycle]);

    useEffect(() => {
      inputRef.current?.focus();
    }, []);

    useEffect(() => {
      if (messageGPT) {
        const areas = extractFunctionalAreas(messageGPT);
        setExtractableAreas(areas.length);
      }
    }, [messageGPT]);

    const extractFunctionalAreas = (
      response: string
    ): { name: string; description: string; business_cycle_id?: number }[] => {
      if (!response) return [];

      const functionalAreas: {
        name: string;
        description: string;
        business_cycle_id?: number;
      }[] = [];

      const sections = response.split(/\n\n|\d+\.\s+/).filter(Boolean);

      sections.forEach((section) => {
        const trimmedSection = section.trim();
        if (!trimmedSection) return;

        const lines = trimmedSection.split("\n").filter(Boolean);
        if (lines.length === 0) return;

        const nameMatch = lines[0].match(/\*\*(.*?)\*\*/);
        const name = nameMatch
          ? nameMatch[1].trim()
          : lines[0].replace(/[:*-]/g, "").trim();

        const description = lines
          .slice(1)
          .map((line) => line.replace(/^[-*]\s*/, "").trim())
          .join(" ")
          .trim();

        if (name && description) {
          functionalAreas.push({
            name,
            description,
            business_cycle_id: selectedCycle?.id,
          });
        }
      });

      return functionalAreas;
    };

    const mergeWithExistingAreas = (newAreas: any[]) => {
      if (!displayedFunctionalAreas || displayedFunctionalAreas.length === 0) {
        return newAreas;
      }

      const existingAreas = [...displayedFunctionalAreas];
      const mergedAreas = [...existingAreas];

      newAreas.forEach((newArea) => {
        // Check if area with same name already exists
        const existingIndex = existingAreas.findIndex(
          (area) => area.name.toLowerCase() === newArea.name.toLowerCase()
        );

        if (existingIndex === -1) {
          // If not found, add the new area
          mergedAreas.push(newArea);
        }
      });

      return mergedAreas;
    };

    const handleExtract = () => {
      const areas = extractFunctionalAreas(messageGPT);
      if (areas.length > 0) {
        const mergedAreas = mergeWithExistingAreas(areas);
        updateTableWithAIData(mergedAreas);
        setDisplayedFunctionalAreas(mergedAreas);
        setExtractableAreas(areas.length);
        message.success({
          content: `${areas.length} functional areas extracted and added to table`,
          className: "custom-message-success",
          icon: <InfoCircleOutlined />,
        });
      } else {
        message.info({
          content: "No valid functional areas found to extract",
          className: "custom-message-info",
        });
      }
    };

    const getLastMessage = () => {
      if (messages.length === 0) return "";
      const lastMessage = messages[messages.length - 1];
      return lastMessage.content;
    };

    const handleSubmit = async () => {
      if (!input.trim()) return;

      const trimmedInput = input.trim().toLowerCase();
      if (["extract", "extract data", "extract areas"].includes(trimmedInput)) {
        handleExtract();
        setInput("");
        return;
      }

      const newMessage: Message = {
        id: Date.now().toString(),
        content: input,
        isUser: true,
        timestamp: new Date(),
      };

      try {
        setMessages((prev) => [...prev, newMessage]);
        setInput("");

        const lastMessage = getLastMessage();
        const data = await trigger({
          prompt: input,
          business_cycle: selectedCycle?.name || "",
          context: lastMessage,
          template: `You are an intelligent business assistant chatbot specialized in creating and refining tailored questionnaires focused on software functionalities or business processes. 
            
            Your response should be strictly valid JSON without any parsing errors in the provided format:
            {{
                "meta_response": "<Meta response to user inputs>",
                "questions": [
                    {{
                        "category": "<Category of question>",
                        "description": "<Actual question text>"
                    }}
                ],
                "follow_up": "<Follow-up question or statement to user>",
                "compliance_matrix": {{
                    "updated": <true/false>,
                    "combined_questions": [
                        {{
                            "category": "<Category of question>",
                            "description": "<Actual question text>"
                        }}
                    ]
                }}
            }}
        
        Here's the possible conversation flow to be followed:

        1. **User Input**: 
        - Accept the user's business challenges or requirements.
        - Perform a search using the \`SemanticSearch\` vector database for relevant information to assist in generating relevant questions.

        2. **Generate Questions**: 
        - Populate the \`questions\` array with questions categorized based on the user's input.
        - Update \`compliance_matrix.updated\` to \`false\`.

        3. **Present Questions and ask Modifications**: 
        - Present questions and ask if they want any modification to the generated questions.

        4. **Decision Point: Questions modifications**:
        After receiving feedback, you will have one of three possibilities:
        - Modification Required:
            - Revise the questions array based on user input..
            - Return to Step 2.
        - No Modification Required: 
            -  Ask the user about adding to the compliance matrix.
            -  Proceed to Step 5.
        
        5. **Decision Point: Adding to compliance matrix**:
        Compliance matrix keeps all the questions throught the conversation upon user consent.
        Based on the user's response:
        - If Yes:
            - Update\`compliance_matrix.combined_questions\` with addition of new questions.
            - Update \`compliance_matrix.updated\` to \`true\`.
            - Inform user about questions being added to combined compliance matrix and ask if they have further use case.
        - If No:
            - Update \`compliance_matrix.updated\` to \`false\`.
            - Return to Step 3 and ask for further modifications.

        Rules:
        - Do not assist user outside scope of chatbot and remain stick to where user left with the process.
        - Please generate a valid JSON without any parsing errors.
        - Ensure all previously added questions are always included in the compliance matrix.`,
        });

        const responseText =
          data?.data?.response ||
          "I am here to help you create and refine functional areas for your RFP. Please specify your requirements.";
        const botMessage: Message = {
          id: Date.now().toString(),
          content: responseText,
          isUser: false,
          timestamp: new Date(),
        };

        setMessageGPT(responseText);
        setMessages((prev) => [...prev, botMessage]);

        const areas = extractFunctionalAreas(responseText);
        setExtractableAreas(areas.length);
        if (areas.length > 0) {
          const mergedAreas = mergeWithExistingAreas(areas);
          updateTableWithAIData(mergedAreas);
          setDisplayedFunctionalAreas(mergedAreas);
        }
      } catch (error) {
        console.error("Error in handleSubmit:", error);
        message.error("Failed to process request");
        setMessages((prev) => prev.filter((msg) => msg.id !== newMessage.id));
      }
    };

    const handleCycleChange = async (cycle: any) => {
      if (!cycle) return;

      const prompt = `Please suggest 5 functional areas for the ${cycle.name} business cycle with detailed descriptions`;

      try {
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            content: `Generating suggestions for ${cycle.name}...`,
            isUser: false,
            timestamp: new Date(),
          },
        ]);

        const lastMessage = getLastMessage();
        const data = await trigger({
          prompt: prompt,
          business_cycle: cycle.name,
          context: lastMessage,
          template: `You are an intelligent business assistant chatbot specialized in creating and refining tailored questionnaires focused on software functionalities or business processes. 
            
            Your response should be strictly valid JSON without any parsing errors in the provided format:
            {{
                "meta_response": "<Meta response to user inputs>",
                "questions": [
                    {{
                        "category": "<Category of question>",
                        "description": "<Actual question text>"
                    }}
                ],
                "follow_up": "<Follow-up question or statement to user>",
                "compliance_matrix": {{
                    "updated": <true/false>,
                    "combined_questions": [
                        {{
                            "category": "<Category of question>",
                            "description": "<Actual question text>"
                        }}
                    ]
                }}
            }}
        
        Here's the possible conversation flow to be followed:

        1. **User Input**: 
        - Accept the user's business challenges or requirements.
        - Perform a search using the \`SemanticSearch\` vector database for relevant information to assist in generating relevant questions.

        2. **Generate Questions**: 
        - Populate the \`questions\` array with questions categorized based on the user's input.
        - Update \`compliance_matrix.updated\` to \`false\`.

        3. **Present Questions and ask Modifications**: 
        - Present questions and ask if they want any modification to the generated questions.

        4. **Decision Point: Questions modifications**:
        After receiving feedback, you will have one of three possibilities:
        - Modification Required:
            - Revise the questions array based on user input..
            - Return to Step 2.
        - No Modification Required: 
            -  Ask the user about adding to the compliance matrix.
            -  Proceed to Step 5.
        
        5. **Decision Point: Adding to compliance matrix**:
        Compliance matrix keeps all the questions throught the conversation upon user consent.
        Based on the user's response:
        - If Yes:
            - Update\`compliance_matrix.combined_questions\` with addition of new questions.
            - Update \`compliance_matrix.updated\` to \`true\`.
            - Inform user about questions being added to combined compliance matrix and ask if they have further use case.
        - If No:
            - Update \`compliance_matrix.updated\` to \`false\`.
            - Return to Step 3 and ask for further modifications.

        Rules:
        - Do not assist user outside scope of chatbot and remain stick to where user left with the process.
        - Please generate a valid JSON without any parsing errors.
        - Ensure all previously added questions are always included in the compliance matrix.`,
        });

        const responseText =
          data?.data?.response || "Unable to generate suggestions.";
        const botMessage: Message = {
          id: Date.now().toString(),
          content: responseText,
          isUser: false,
          timestamp: new Date(),
        };

        setMessageGPT(responseText);
        setMessages((prev) => [...prev.slice(0, -1), botMessage]);

        const areas = extractFunctionalAreas(responseText);
        setExtractableAreas(areas.length);
        if (areas.length > 0) {
          const mergedAreas = mergeWithExistingAreas(areas);
          updateTableWithAIData(mergedAreas);
          setDisplayedFunctionalAreas(mergedAreas);
        }
      } catch (error) {
        console.error("Error in handleCycleChange:", error);
        message.error("Failed to generate suggestions");
      }
    };

    const formatTime = (date?: Date) => {
      if (!date) return "";
      return date.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      });
    };

    return (
      <Card
        className="chatbot-card"
        bordered={false}
        style={{
          height: "600px",
          display: "flex",
          flexDirection: "column",
          boxShadow: "0 4px 12px rgba(0, 0, 0, 0.08)",
          borderRadius: "12px",
          overflow: "hidden",
        }}
        bodyStyle={{
          padding: 0,
          display: "flex",
          flexDirection: "column",
          height: "100%",
        }}
      >
        {/* Header */}
        <div
          style={{
            background: "linear-gradient(90deg, #1a56db 0%, #3b82f6 100%)",
            padding: "16px 20px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <div
              style={{
                background: "rgba(255, 255, 255, 0.2)",
                borderRadius: "50%",
                width: "36px",
                height: "36px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <RobotOutlined style={{ color: "white", fontSize: "18px" }} />
            </div>
            <div>
              <Title level={4} style={{ margin: 0, color: "white" }}>
                AI Assistant
              </Title>
              <Text
                style={{ color: "rgba(255, 255, 255, 0.8)", fontSize: "12px" }}
              >
                {selectedCycle?.name
                  ? `Working with ${selectedCycle.name}`
                  : "Select a business cycle"}
              </Text>
            </div>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            {selectedCycle && (
              <Tag
                color="blue"
                style={{
                  borderRadius: "12px",
                  padding: "0 10px",
                  background: "rgba(255, 255, 255, 0.15)",
                  border: "none",
                  color: "white",
                }}
              >
                {selectedCycle.name}
              </Tag>
            )}

            <Tooltip
              title={`Extract ${extractableAreas} functional areas to table`}
            >
              <Badge
                count={extractableAreas > 0 ? extractableAreas : 0}
                offset={[-5, 5]}
              >
                <Button
                  type="primary"
                  icon={<ExportOutlined />}
                  onClick={handleExtract}
                  disabled={!messageGPT || extractableAreas === 0}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    backgroundColor: "rgba(255, 255, 255, 0.2)",
                    borderColor: "transparent",
                    boxShadow: "none",
                  }}
                >
                  <span style={{ marginLeft: "4px" }}>Extract</span>
                </Button>
              </Badge>
            </Tooltip>
          </div>
        </div>

        {/* Messages Area */}
        <div
          style={{
            flex: 1,
            padding: "16px",
            overflowY: "auto",
            background: "linear-gradient(180deg, #f0f7ff 0%, #ffffff 100%)",
            minHeight: "400px",
            maxHeight: "calc(100vh - 220px)",
          }}
        >
          {messages.length === 1 && messages[0].id === "welcome" && (
            <div style={{ marginBottom: "16px", marginTop: "8px" }}>
              <Card
                style={{
                  background: "rgba(59, 130, 246, 0.08)",
                  border: "1px solid rgba(59, 130, 246, 0.2)",
                  borderRadius: "8px",
                }}
              >
                <div style={{ display: "flex", alignItems: "flex-start" }}>
                  <BulbOutlined
                    style={{
                      color: "#3b82f6",
                      fontSize: "18px",
                      marginRight: "12px",
                      marginTop: "4px",
                    }}
                  />
                  <div>
                    <Paragraph
                      style={{ color: "#1e40af", marginBottom: "8px" }}
                    >
                      <strong>{"Tips:"}</strong>
                    </Paragraph>
                    <ul
                      style={{
                        listStyleType: "disc",
                        paddingLeft: "20px",
                        color: "#3b82f6",
                        margin: 0,
                      }}
                    >
                      <li>
                        Ask for functional areas specific to your business cycle
                      </li>
                      <li>Request detailed descriptions for each area</li>
                      <li>
                        {` Type "extract" to add AI suggestions to your table`}
                      </li>
                    </ul>
                  </div>
                </div>
              </Card>
            </div>
          )}

          <List
            dataSource={messages}
            renderItem={(item) => (
              <List.Item
                style={{
                  border: "none",
                  padding: "8px 0",
                  display: "flex",
                  justifyContent: item.isUser ? "flex-end" : "flex-start",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: "85%",
                    alignItems: item.isUser ? "flex-end" : "flex-start",
                  }}
                >
                  <div style={{ display: "flex", alignItems: "flex-start" }}>
                    {!item.isUser && (
                      <div
                        style={{
                          backgroundColor: "#3b82f6",
                          marginRight: "8px",
                          height: "32px",
                          width: "32px",
                          borderRadius: "50%",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          flexShrink: 0,
                        }}
                      >
                        <RobotOutlined
                          style={{ color: "white", fontSize: "16px" }}
                        />
                      </div>
                    )}
                    <div
                      style={{
                        padding: "12px 16px",
                        borderRadius: "16px",
                        boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
                        backgroundColor: item.isUser ? "#3b82f6" : "#ffffff",
                        color: item.isUser ? "#ffffff" : "#333333",
                        borderBottomRightRadius: item.isUser ? "4px" : "16px",
                        borderBottomLeftRadius: item.isUser ? "16px" : "4px",
                        border: item.isUser ? "none" : "1px solid #e5e7eb",
                      }}
                    >
                      <div
                        style={{
                          whiteSpace: "pre-line",
                          lineHeight: "1.5",
                          wordBreak: "break-word",
                        }}
                      >
                        {item.content}
                      </div>

                      {item.rfpSections && (
                        <div style={{ marginTop: "12px" }}>
                          <Divider style={{ margin: "8px 0" }} />
                          <Collapse
                            accordion
                            style={{
                              background: "transparent",
                              border: "none",
                            }}
                            expandIconPosition="end"
                          >
                            {Object.entries(item.rfpSections).map(
                              ([title, content]) => (
                                <Collapse.Panel
                                  header={
                                    <span style={{ fontWeight: 500 }}>
                                      {title}
                                    </span>
                                  }
                                  key={title}
                                  style={{
                                    border: "none",
                                    background: "transparent",
                                    marginBottom: "4px",
                                  }}
                                >
                                  <p
                                    style={{
                                      color: item.isUser
                                        ? "#e6f0ff"
                                        : "#4b5563",
                                    }}
                                  >
                                    {content}
                                  </p>
                                </Collapse.Panel>
                              )
                            )}
                          </Collapse>
                        </div>
                      )}
                    </div>
                    {item.isUser && (
                      <Avatar
                        icon={<UserOutlined />}
                        style={{
                          backgroundColor: "#1d4ed8",
                          marginLeft: "8px",
                          boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontSize: "14px",
                          flexShrink: 0,
                        }}
                        size={32}
                      />
                    )}
                  </div>
                  <Text
                    type="secondary"
                    style={{
                      fontSize: "11px",
                      marginTop: "4px",
                      marginLeft: item.isUser ? "0" : "40px",
                      marginRight: item.isUser ? "40px" : "0",
                    }}
                  >
                    {formatTime(item.timestamp)}
                  </Text>
                </div>
              </List.Item>
            )}
          />
          {isMutating && (
            <div
              style={{
                display: "flex",
                alignItems: "flex-start",
                marginLeft: "40px",
                maxWidth: "85%",
                marginTop: "8px",
              }}
            >
              <Avatar
                icon={<RobotOutlined />}
                style={{
                  backgroundColor: "#3b82f6",
                  marginRight: "8px",
                }}
              />
              <div
                style={{
                  padding: "12px 16px",
                  borderRadius: "16px",
                  borderBottomLeftRadius: "4px",
                  backgroundColor: "#ffffff",
                  border: "1px solid #e5e7eb",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
                }}
              >
                <div style={{ display: "flex", alignItems: "center" }}>
                  <Spin
                    indicator={
                      <LoadingOutlined
                        style={{ fontSize: 16, color: "#3b82f6" }}
                        spin
                      />
                    }
                  />
                  <Text style={{ marginLeft: "8px", color: "#6b7280" }}>
                    Thinking...
                  </Text>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div
          style={{
            borderTop: "1px solid #e5e7eb",
            padding: "16px 20px",
            backgroundColor: "#ffffff",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              backgroundColor: "#f3f4f6",
              borderRadius: "24px",
              padding: "4px 16px",
            }}
          >
            <Input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Ask me about ${
                selectedCycle?.name || "your business cycle"
              } or type "extract" to add suggestions...`}
              onPressEnter={handleSubmit}
              disabled={isMutating}
              style={{
                flex: 1,
                border: "none",
                backgroundColor: "transparent",
                padding: "8px 0",
                boxShadow: "none",
              }}
              bordered={false}
            />
            <Button
              type="primary"
              icon={<SendOutlined />}
              onClick={handleSubmit}
              loading={isMutating}
              disabled={isMutating || !input.trim()}
              style={{
                borderRadius: "50%",
                width: "40px",
                height: "40px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: 0,
                marginLeft: "8px",
                boxShadow: "0 2px 5px rgba(59, 130, 246, 0.3)",
              }}
            />
          </div>
          {extractableAreas > 0 && (
            <div style={{ marginTop: "8px", textAlign: "center" }}>
              <Text type="secondary" style={{ fontSize: "12px" }}>
                <InfoCircleOutlined style={{ marginRight: "4px" }} />
                {` ${extractableAreas} functional areas available. Type "extract" to add them to your table.`}
              </Text>
            </div>
          )}
        </div>
      </Card>
    );
  }
);

// Add display name to the component
ChatBot.displayName = "ChatBot";

export default ChatBot;
