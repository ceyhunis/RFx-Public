"use client";
import React from "react";
import useSWR from "swr";
import DashboardTopBar from "@/components/General/TopBar";
import { Card, Row, Col, Typography, Button } from "antd";
import { useRouter } from "next/navigation";
import {
  FileText,
  Users,
  BarChart,
  Clock,
  ChevronDown,
  Plus,
} from "lucide-react";
import { DynamicRouter } from "@/utils/request_utils";
import { useSession } from "next-auth/react";

const { Title } = Typography;

// Define custom styles for Lucide icons to match Ant Design
const iconStyle = {
  width: 16,
  height: 16,
  color: "#8c8c8c",
};


const DashboardMetricCard = ({
  icon: Icon,
  title,
  value,
}: {
  icon: React.ElementType;
  title: string;
  value: string;
}) => (
  <Card>
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: "4px",
        color: "#8c8c8c",
      }}
    >
      <Icon style={{ ...iconStyle, width: 12, height: 12 }} />
      <span style={{ fontSize: "12px" }}>{title}</span>
    </div>
    <div style={{ fontSize: "18px", fontWeight: "500", marginTop: "4px" }}>
      {value}
    </div>
  </Card>
);


const Dashboard = () => {
  const {data:session} = useSession();
  const router = useRouter();
  const url = DynamicRouter("project", "dashboard",{
    user_id: session?.user?.id,
  });
  const { data, error } = useSWR(url);
  const datasource = data?.data;

  if (error) return <div>Failed to load metrics</div>;
  if (!data) return <div>Loading...</div>;

  const metrics = [
    { icon: FileText, title: "Active RFx", value: datasource.active_rfx_count || 0 },
    { icon: Users, title: "Participating Suppliers", value: datasource.provider_count || 0 },
    { icon: BarChart, title: "Completion Rate", value: `${datasource.completion_rate || 0}%` },
    { icon: Clock, title: "Avg. Response Time", value: `${datasource.avg_response_time || 0} days` },
  ];

  return (
    <div style={{ padding: "16px" }}>
      <Row
        justify="space-between"
        align="middle"
        style={{ marginBottom: "16px" }}
      >
        <Col>
          <Title level={4} style={{ margin: 0 }}>
            Dashboard
          </Title>
        </Col>
        <Col>
          <Button
            onClick={() => {
              router.push("/panel/generate");
            }}
            style={{
              fontSize: "14px",
              backgroundColor: "#0033fe",
              color: "white",
              height: "40px",
              padding: "0 25px",
              display: "flex",
              alignItems: "center",
              gap: "8px",
              border: "none",
            }}
          >
            <Plus style={{ ...iconStyle, color: "white" }} />
            New RFX
          </Button>
        </Col>
      </Row>

      {/* Metrics Grid */}
      <Row gutter={[16, 16]} style={{ marginBottom: "24px" }}>
        {metrics.map((metric, index) => (
          <Col xs={24} sm={12} lg={6} key={index}>
            <DashboardMetricCard {...metric} />
          </Col>
        ))}
      </Row>

      {/* Projects Section */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "16px",
        }}
      >
        {/* <Title level={5} style={{ margin: 0 }}>
          Ongoing RFx Projects
        </Title> */}
      </div>

      {/* Project Cards */}
      <Row
        justify="space-between"
        align="middle"
        style={{ marginBottom: "16px", width: "100%" }}
      >
      </Row>
    </div>
  );
};

export default function PanelScreen() {
  return (
    <div style={{ margin: "0 0px 0px 70px" }}>
      <DashboardTopBar />
      <Dashboard />
    </div>
  );
}
