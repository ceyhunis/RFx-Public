"use client";

import { ApiResponse } from "@/types/general_types";
import { fetcher, DynamicRouter } from "@/utils/request_utils";
import { useParams } from "next/navigation";
import React, { useState } from "react";
import useSWR from "swr";
import {
  Descriptions,
  Skeleton,
  Alert,
  Row,
  Col,
  Table,
  Tag,
  Space,
  Button,
} from "antd";
import { GenerateProvider } from "@/lib/providers/GenerateContextProvider";
import ChooseCompanyModal from "../../generate/components/ChooseCompanyModal";
import { DownloadOutlined } from "@ant-design/icons";
import { notify } from "@/utils/functions_utils";
import useSWRMutation from "swr/mutation";
import { useRouter } from "next/navigation";

const postRequest = async (url: string, { arg }: { arg: any }) => {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(arg),
  });
  return response.json();
};

export default function RFPDetailPage() {
  const { id } = useParams();
  const router = useRouter();

  console.log("Fetched ID:", id);

  const detailUrl = DynamicRouter("project", "generated-rfp", { id });
  const { data, error } = useSWR<ApiResponse<any>>(detailUrl, fetcher, {
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
  });

  const [modalOpen, setModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const rfpId = Array.isArray(id) ? id[0] : id;

  const sendUrl = DynamicRouter("project", "choose-company", { id });
  const { trigger } = useSWRMutation(sendUrl, postRequest);

  if (error) {
    console.error("API Fetch Error:", error);
    return (
      <Alert message="Error" description="Failed to load data" type="error" />
    );
  }
  if (!data || !data.data || data.data.length === 0) return <Skeleton active />;

  console.log("API Response Data:", data);

  const {
    rfp_name,
    rfp_description,
    value_propositions,
    company_url,
    services = [],
    business_cycles = [],
    industry,
    areas = [],
  } = data.data[0];

  const renderPriorityTag = (priority: string) => {
    switch (priority?.toLowerCase()) {
      case "high":
        return <Tag color="red">High</Tag>;
      case "medium":
        return <Tag color="orange">Medium</Tag>;
      case "low":
        return <Tag color="green">Low</Tag>;
      default:
        return <Tag color="gray">Not Selected</Tag>;
    }
  };

  const combinedData = business_cycles.map((cycle: any, index: number) => ({
    key: `cycle-${index}`,
    cycleName: cycle.name || `Business Cycle ${cycle}`,
    functionalArea: areas[index]?.name || "-",
    functionalityDescription: areas[index]?.description || "-",
    priority: renderPriorityTag("low"),
  }));

  const dataTable = [
    {
      key: "1",
      documentName: rfp_name,
      documentDescription: rfp_description,
      companyUrl: company_url,
      companyDescription: value_propositions,
      industry: `Industry ${industry}`,
    },
  ];

  return (
    <GenerateProvider>
      <Row justify="end" style={{ marginTop: 20, marginRight: 50 }}>
        <Button
          type="primary"
          size="large"
          onClick={() => router.push("/panel/rfx")}
        >
          Back to RFX List
        </Button>
      </Row>
      <Row justify="center" style={{ maxHeight: "600px" }}>
        <Col xs={24}>
          <div style={{ padding: 10, marginLeft: 100, marginRight: 40 }}>
            <Table
              dataSource={dataTable}
              columns={[
                {
                  title: "Document Name",
                  dataIndex: "documentName",
                  key: "documentName",
                },
                {
                  title: "Document Description",
                  dataIndex: "documentDescription",
                  key: "documentDescription",
                },
                {
                  title: "Company Website (URL)",
                  dataIndex: "companyUrl",
                  key: "companyUrl",
                },
                {
                  title: "Company Description",
                  dataIndex: "companyDescription",
                  key: "companyDescription",
                },
                { title: "Industry", dataIndex: "industry", key: "industry" },
              ]}
              pagination={false}
              bordered
              className="general-table"
            />

            {services.length > 0 && (
              <Descriptions bordered className="custom-descriptions">
                <Descriptions.Item label="SERVICES" span={2}>
                  <Row gutter={16}>
                    {services.map((service: any, index: number) => (
                      <Col key={`service-${index}`} className="borderless-cell">
                        {service.name || `Service ${index + 1}`}
                      </Col>
                    ))}
                  </Row>
                </Descriptions.Item>
              </Descriptions>
            )}

            <Table
              dataSource={combinedData}
              columns={[
                {
                  title: "Business Cycles",
                  dataIndex: "cycleName",
                  key: "cycleName",
                },
                {
                  title: "Functional Areas",
                  dataIndex: "functionalArea",
                  key: "functionalArea",
                },
                {
                  title: "Functionality Descriptions",
                  dataIndex: "functionalityDescription",
                  key: "functionalityDescription",
                },
                { title: "Priority", dataIndex: "priority", key: "priority" },
              ]}
              pagination={false}
              bordered
              className="business-cycle-table"
            />
            <Row justify="end" style={{ marginTop: 40, marginRight: 10 }}>
              <Space>
                <Button
                  type="primary"
                  onClick={() => {}}
                  size="large"
                  icon={<DownloadOutlined />}
                >
                  Export PDF
                </Button>
                <Button
                  type="primary"
                  onClick={() => setModalOpen(true)}
                  size="large"
                >
                  Choose Company
                </Button>
              </Space>
            </Row>
          </div>
          <ChooseCompanyModal
            isOpen={modalOpen}
            onClose={() => setModalOpen(false)}
            loading={loading}
            rfpId={rfpId}
            documentName={rfp_name}
            onSubmit={async (values) => {
              setLoading(true);
              try {
                const response = await trigger(values);
                if (response.statusCode === 200) {
                  notify(response.message, "success");
                } else {
                  notify(response.message, "error");
                }
              } finally {
                setLoading(false);
                setModalOpen(false);
              }
            }}
          />
        </Col>
      </Row>
    </GenerateProvider>
  );
}
