"use client";

import React, { useState, useEffect } from "react";
import useSWR from "swr";
import {
  Row,
  Col,
  Typography,
  Input,
  Select,
  Card,
  Avatar,
  Tag,
  Tooltip,

  Button,
  Modal,
  Form,
  message,

} from "antd";
import {
  SortAscendingOutlined,
  SortDescendingOutlined,
  UserOutlined,
  TeamOutlined,
  MailOutlined,
} from "@ant-design/icons";
import DashboardTopBar from "@/components/General/TopBar";
import WorkerCard from "@/components/General/WorkerCard";
import PageHeader from "@/components/General/PageHeader";
import { DynamicRouter, fetcher } from "@/utils/request_utils";
import { useSession } from "next-auth/react";
import Loader from "@/components/components/general/Loader";
import { ApiResponse } from "@/types/general_types";
// Add EmailJS import
import emailjs from "@emailjs/browser";

const { Title, Text } = Typography;
const { Search } = Input;
const { Option } = Select;

// EmailJS configuration
const EMAILJS_SERVICE_ID = "contact_service";
const EMAILJS_TEMPLATE_ID = "invite_member";
const EMAILJS_PUBLIC_KEY = "SMQEUuUI-B5bdaxMv";

interface Worker {
  id: number;
  first_name: string;
  last_name: string;
  email: string;
  business_cycles: string[];
}

interface OrganizationData {
  members: Worker[];
}

export default function PanelScreen() {
  const { data: session } = useSession();
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortOrder, setSortOrder] = useState("asc");
  const [selectedCycles, setSelectedCycles] = useState<string[]>([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [form] = Form.useForm();

  // Initialize EmailJS on component mount
  useEffect(() => {
    emailjs.init(EMAILJS_PUBLIC_KEY);
  }, []);

  const userId = session?.user?.id || 0;
  const urlOrganizationMembers = DynamicRouter("auth", "organization-members", {
    user_id: userId,
  });

  const {
    data: orgData,
    error: orgError,
    isLoading: orgLoading,
    mutate: mutateOrg,
  } = useSWR<ApiResponse<OrganizationData>>(
    urlOrganizationMembers,
    () => fetcher<OrganizationData>(urlOrganizationMembers),
    { revalidateOnFocus: false }
  );

  const urlInviteMember = DynamicRouter("auth", "invite-member");

  const handleViewChange = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      setIsTransitioning(false);
    }, 300);
  };

  const handleInviteMember = () => {
    setIsModalVisible(true);
  };

  // Function to send invitation email directly using EmailJS
  const sendEmailJSInvitation = async (
    email: string,
    orgName: string,
    inviterName: string,
    token: string // Add token parameter
  ): Promise<boolean> => {
    try {
      const baseUrl = window.location.origin;
      const inviteLink = `${baseUrl}/register?token=${token}&email=${email}`;

      const templateParams = {
        to_email: email,
        from_email: (session?.user as any).email, // Inviter's email added
        organization_name: orgName || "Our Organization",
        inviter_name: inviterName,
        link: inviteLink,
        to_name: email.split("@")[0],
      };

      const response = await emailjs.send(
        EMAILJS_SERVICE_ID,
        EMAILJS_TEMPLATE_ID,
        templateParams
      );

      console.log("EmailJS Success:", response);
      return true;
    } catch (error) {
      console.error("EmailJS Error:", error);
      return false;
    }
  };

  const handleInviteSubmit = async () => {
    try {
      const values = await form.validateFields();
      const { email } = values;

      message.loading({
        content: "Sending invitation...",
        key: "inviteLoading",
        duration: 0,
      });

      const response = await fetch(urlInviteMember, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          user_id: userId,
        }),
      });

      const result = await response.json();

      if (response.ok) {
        if (result.data && !result.data.email_sent) {
          const organizationId = session?.user?.organization_id;
          const organizationName = organizationId
            ? "Your Organization"
            : "Our Organization";
          const inviterName = `${session?.user?.first_name || ""} ${
            session?.user?.last_name || ""
          }`.trim();

          // Always use hashed_token
          const emailJsSent = await sendEmailJSInvitation(
            email,
            organizationName,
            inviterName,
            result.data.hashed_token
          );

          if (emailJsSent) {
            message.success({
              content: `Invitation email sent to ${email} (via client)`,
              key: "inviteLoading",
              duration: 4,
            });
          } else {
            message.success({
              content: `Invitation created for ${email}, but email delivery failed`,
              key: "inviteLoading",
              duration: 4,
            });
          }
        } else {
          message.success({
            content: `Invitation email sent to ${email}`,
            key: "inviteLoading",
            duration: 4,
          });
        }
        setIsModalVisible(false);
        form.resetFields();
        // Refresh organization data
        mutateOrg();
      } else {
        message.error({
          content: result.message || "Failed to send invitation",
          key: "inviteLoading",
          duration: 4,
        });
      }
    } catch (error) {
      message.error({
        content: "Please enter a valid email address",
        key: "inviteLoading",
      });
    }
  };

  const handleCancel = () => {
    setIsModalVisible(false);
    form.resetFields();
  };

  if (orgError) return <div>Error loading data</div>;
  if (!orgData?.data) return <div>Loading...</div>;

  const organizationData: Worker[] = orgData.data.members || [];

  const filteredWorkers = organizationData
    .filter((worker) =>
      `${worker.first_name} ${worker.last_name} ${worker.email}`
        .toLowerCase()
        .includes(searchTerm.toLowerCase())
    )
    .filter((worker) =>
      selectedCycles.length > 0
        ? selectedCycles.every((cycle) =>
            worker.business_cycles.includes(cycle)
          )
        : true
    )
    .sort((a, b) => {
      const nameA = `${a.first_name} ${a.last_name}`.toLowerCase();
      const nameB = `${b.first_name} ${b.last_name}`.toLowerCase();
      if (sortOrder === "asc") {
        return nameA.localeCompare(nameB);
      } else {
        return nameB.localeCompare(nameA);
      }
    });

  const cardStyles = (index: number) => ({
    opacity: isTransitioning ? 0 : 1,
    transform: `scale(${isTransitioning ? 0.9 : 1})`,
    transition: `all 0.3s ease ${index * 0.1}s`,
  });

  // Get unique business cycles for filter dropdown
  const uniqueBusinessCycles = Array.from(
    new Set(organizationData.flatMap((worker) => worker.business_cycles))
  ).filter(Boolean);

  return (
    <Loader isLoading={orgLoading}>
      <div>
        <DashboardTopBar />
        <PageHeader
          title="Organization Members"
          setViewType={handleViewChange}
          showActions={false}
        />
        <div
          style={{
            position: "relative",
            padding: "0 16px 48px",
            marginBottom: "24px",
            opacity: isTransitioning ? 0 : 1,
            transform: `translateY(${isTransitioning ? "20px" : "0"})`,
            transition: "opacity 0.3s ease, transform 0.3s ease",
          }}
        >
          {session && (
            <div style={{ marginBottom: "32px" }}>
              <Card
                style={{

                  maxWidth: "800px",

                    
                  margin: "0 auto",
                  boxShadow: "0 4px 12px rgba(0, 0, 0, 0.08)",
                  borderRadius: "8px",
                  overflow: "hidden",
                  borderColor: "#f0f0f0",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",

                    flexWrap: "wrap",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      flexWrap: "wrap",
                      gap: "16px",
                    }}
                  >


                    <Avatar
                      size={64}
                      icon={<UserOutlined />}
                      style={{ backgroundColor: "#0033fe" }}
                    />
                    <div>
                      <Title level={4} style={{ margin: 0 }}>
                        {(session.user as any).first_name}{" "}
                        {(session.user as any).last_name}
                      </Title>
                      <Text type="secondary">
                        <MailOutlined style={{ marginRight: "8px" }} />
                        {(session.user as any).email}
                      </Text>
                      <div style={{ marginTop: "8px" }}>
                        <Tag color="#0033fe">Organization Admin</Tag>
                      </div>
                    </div>
                  </div>
                  <div>
                    <TeamOutlined
                      style={{ fontSize: "24px", color: "#0033fe" }}
                    />
                    <Text strong style={{ marginLeft: "8px" }}>
                      {organizationData.length} Members
                    </Text>
                  </div>
                </div>
              </Card>
            </div>
          )}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "24px",
              flexWrap: "wrap",
              gap: "16px",

              maxWidth: "1200px",
              margin: "0 auto 24px",

            }}
          >
            <Search
              placeholder="Search by name or email"
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ width: "100%", maxWidth: "300px" }}
              allowClear
            />


            <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" }}>

              <Select
                defaultValue="asc"
                onChange={(value) => setSortOrder(value)}
                style={{

                  width: "100%",
                  maxWidth: "150px",

                  borderRadius: "6px",
                }}
                suffixIcon={
                  sortOrder === "asc" ? (
                    <SortAscendingOutlined />
                  ) : (
                    <SortDescendingOutlined />
                  )
                }
              >
                <Option value="asc">Sort by (A-Z)</Option>
                <Option value="desc">Sort by (Z-A)</Option>
              </Select>

              <Select
                mode="multiple"
                placeholder="Filter by Business Cycle"
                onChange={(value) => setSelectedCycles(value)}
                allowClear
                style={{

                  width: "100%",
                  maxWidth: "300px",

                  borderRadius: "6px",
                }}
                maxTagCount={2}
              >
                {uniqueBusinessCycles.map((cycle) => (
                  <Option key={cycle} value={cycle}>
                    {cycle}
                  </Option>
                ))}
              </Select>
            </div>
          </div>


          <Row gutter={[16, 16]}>

            {filteredWorkers.map((worker, index) => (
              <Col
                key={worker.id}
                xs={24}
                sm={12}
                md={8}
                lg={6}
                style={cardStyles(index)}
              >
                <WorkerCard
                  name={`${worker.first_name} ${worker.last_name}`}
                  email={worker.email}
                  business_cycles={
                    worker.business_cycles.length > 0
                      ? worker.business_cycles
                      : []
                  }
                  user_id={worker.id}
                  mutate={mutateOrg}
                />
              </Col>
            ))}

            {filteredWorkers.length === 0 && (
              <Col span={24}>
                <div
                  style={{
                    textAlign: "center",
                    padding: "40px 0",
                    background: "#f9f9f9",
                    borderRadius: "8px",
                    width: "100%",
                  }}
                >
                  <TeamOutlined
                    style={{ fontSize: "48px", color: "#d9d9d9" }}
                  />
                  <Title
                    level={5}
                    style={{ marginTop: "16px", color: "#8c8c8c" }}
                  >
                    No members found matching your criteria
                  </Title>
                </div>
              </Col>
            )}
          </Row>
        </div>
      </div>

      {/* Modal bileşeni */}
      <Modal
        title="Invite a New Member"
        open={isModalVisible}
        onOk={handleInviteSubmit}
        onCancel={handleCancel}
        okText="Send Invitation"
      >
        <Form form={form} layout="vertical">
          <Form.Item
            label="Email"
            name="email"
            rules={[
              { required: true, message: "Please enter an email address" },
              { type: "email", message: "Please enter a valid email address" },
            ]}
          >
            <Input placeholder="Enter email address" />
          </Form.Item>
          <p style={{ fontSize: "13px", color: "#666" }}>
            An invitation email will be sent with a unique link that allows the
            recipient to join your organization. The invitation will expire
            after 24 hours.
          </p>
        </Form>
      </Modal>
    </Loader>
  );
}
