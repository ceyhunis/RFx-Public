"use client";

import React, { useState, useEffect } from "react";
import useSWR from "swr";
import useSWRMutation from "swr/mutation";
import {
  Row,
  Col,
  Typography,
  Card,
  Button,
  Input,
  Form,
  List,
  Avatar,
  Divider,
  Empty,
  Badge,
  Spin,
  Modal,
  notification,
} from "antd";
import {
  MessageOutlined,
  SendOutlined,
  PlusOutlined,
  UserOutlined,
  QuestionCircleOutlined,
} from "@ant-design/icons";
import DashboardTopBar from "@/components/General/TopBar";
import PageHeader from "@/components/General/PageHeader";
import { DynamicRouter, fetcher, postRequest } from "@/utils/request_utils";
import { useSession } from "next-auth/react";
import Loader from "@/components/components/general/Loader";

const { Title, Text, Paragraph } = Typography;
const { TextArea } = Input;

interface Ticket {
  id: number;
  subject: string;
  description: string;
  status: "open" | "closed" | "pending";
  created_at: string;
  updated_at: string;
  messages: TicketMessage[];
}

interface TicketMessage {
  id: number;
  content: string;
  created_at: string;
  is_staff: boolean;
  user_name: string;
}

interface ApiResponse<T> {
  data: T;
  message: string;
  statusCode: number;
}

// Notification helper function to replace the missing import
const notify = (
  message: string,
  type: "success" | "error" | "info" | "warning"
) => {
  notification[type]({
    message: type.charAt(0).toUpperCase() + type.slice(1),
    description: message,
  });
};

export default function SupportPage() {
  const { data: session, status } = useSession();
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [isNewTicketModalVisible, setIsNewTicketModalVisible] = useState(false);
  const [form] = Form.useForm();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [viewType, setViewType] = useState<"list" | "detail">("list");

  const userId = session?.user?.id || 0;
  const urlTickets = DynamicRouter("project", "support-tickets", {
    user_id: userId,
    email: session?.user?.email,
  });

  const supportURL = DynamicRouter("project", "outseta-support");
  const { trigger: triggerSupport } = useSWRMutation(supportURL, postRequest);

  const {
    data: ticketsData,
    error: ticketsError,
    isLoading: ticketsLoading,
    mutate: mutateTickets,
  } = useSWR<ApiResponse<Ticket[]>>(userId ? urlTickets : null, fetcher, {
    revalidateOnFocus: false,
  });

  const tickets: Ticket[] = ticketsData?.data || [];

  useEffect(() => {
    if (tickets.length > 0 && !selectedTicket) {
      setSelectedTicket(tickets[0]);
    }
  }, [tickets, selectedTicket]);

  // Fetch support tickets when component mounts or userId changes
  useEffect(() => {
    if (userId) {
      mutateTickets();
    }
  }, [userId, mutateTickets]);

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedTicket) return;

    setIsSubmitting(true);
    try {
      const response = await fetch(
        DynamicRouter("support", "messages", {
          ticket_id: selectedTicket.id,
        }),
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            content: newMessage,
            user_id: userId,
          }),
        }
      );

      if (response.ok) {
        setNewMessage("");
        mutateTickets();
      } else {
        console.error("Failed to send message");
        notify("Failed to send message", "error");
      }
    } catch (error) {
      console.error("Error sending message:", error);
      notify("Error sending message", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCreateTicket = async (values: {
    subject: string;
    description: string;
  }) => {
    setIsSubmitting(true);
    try {
      // Using Outseta support system
      const supportData = {
        FromPerson: { Uid: session?.user?.outseta_uid || "OW42oZYQ" },
        Subject: values.subject,
        Body: values.description,
        Source: 2,
      };

      triggerSupport(supportData, {
        onSuccess: (response) => {
          if (response.statusCode === 200) {
            notify("Support request submitted successfully", "success");
            form.resetFields();
            setIsNewTicketModalVisible(false);
            mutateTickets();
          } else {
            notify(
              response.message || "Failed to submit support request",
              "error"
            );
          }
          setIsSubmitting(false);
        },
        onError: () => {
          notify("Error submitting support request", "error");
          setIsSubmitting(false);
        },
      });
    } catch (error) {
      console.error("Error creating ticket:", error);
      notify("Error creating support ticket", "error");
      setIsSubmitting(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open":
        return "green";
      case "pending":
        return "orange";
      case "closed":
        return "red";
      default:
        return "blue";
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  // Handle view type change to match PageHeader's expected function signature
  const handleViewTypeChange = (newViewType: "table" | "card") => {
    // Map the incoming view type to our internal state
    setViewType(newViewType === "table" ? "list" : "detail");
  };

  return (
    <div style={{ margin: "0 0px 0px 70px" }}>
      <DashboardTopBar />
      <PageHeader
        title="Support Center"
        showActions={false}
        setViewType={handleViewTypeChange}
      />

      <Loader isLoading={ticketsLoading}>
        <div style={{ padding: "0 24px 48px" }}>
          <Row gutter={[24, 24]}>
            <Col xs={24} md={8}>
              <Card
                title={
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <span>My Tickets</span>
                    <Button
                      type="primary"
                      icon={<PlusOutlined />}
                      onClick={() => setIsNewTicketModalVisible(true)}
                    >
                      New Ticket
                    </Button>
                  </div>
                }
                style={{ height: "calc(100vh - 200px)", overflowY: "auto" }}
              >
                {tickets.length === 0 ? (
                  <Empty
                    description="No support tickets yet"
                    image={Empty.PRESENTED_IMAGE_SIMPLE}
                  />
                ) : (
                  <List
                    dataSource={tickets}
                    renderItem={(ticket) => (
                      <List.Item
                        onClick={() => setSelectedTicket(ticket)}
                        style={{
                          cursor: "pointer",
                          backgroundColor:
                            selectedTicket?.id === ticket.id
                              ? "#f0f5ff"
                              : "transparent",
                          padding: "12px",
                          borderRadius: "4px",
                          marginBottom: "8px",
                        }}
                      >
                        <List.Item.Meta
                          avatar={<Avatar icon={<QuestionCircleOutlined />} />}
                          title={
                            <div
                              style={{
                                display: "flex",
                                justifyContent: "space-between",
                              }}
                            >
                              <Text strong>{ticket.subject}</Text>
                              <Badge
                                status={getStatusColor(ticket.status) as any}
                                text={ticket.status}
                              />
                            </div>
                          }
                          description={
                            <Text type="secondary" ellipsis>
                              {ticket.description}
                            </Text>
                          }
                        />
                      </List.Item>
                    )}
                  />
                )}
              </Card>
            </Col>

            <Col xs={24} md={16}>
              <Card
                title={
                  selectedTicket ? (
                    <div>
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                        }}
                      >
                        <Title level={5}>{selectedTicket.subject}</Title>
                        <Badge
                          status={getStatusColor(selectedTicket.status) as any}
                          text={selectedTicket.status}
                        />
                      </div>
                      <Text type="secondary">
                        Created on {formatDate(selectedTicket.created_at)}
                      </Text>
                    </div>
                  ) : (
                    "Select a ticket"
                  )
                }
                style={{
                  height: "calc(100vh - 200px)",
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                {!selectedTicket ? (
                  <Empty
                    description="Select a ticket to view conversation"
                    image={Empty.PRESENTED_IMAGE_SIMPLE}
                    style={{ margin: "auto" }}
                  />
                ) : (
                  <>
                    <div
                      style={{
                        flexGrow: 1,
                        overflowY: "auto",
                        padding: "0 8px",
                      }}
                    >
                      <Paragraph>{selectedTicket.description}</Paragraph>
                      <Divider />

                      {selectedTicket.messages &&
                      selectedTicket.messages.length > 0 ? (
                        selectedTicket.messages.map((message) => (
                          <div
                            key={message.id}
                            style={{
                              marginBottom: "16px",
                              display: "flex",
                              flexDirection: message.is_staff
                                ? "row"
                                : "row-reverse",
                            }}
                          >
                            <Avatar
                              icon={<UserOutlined />}
                              style={{
                                backgroundColor: message.is_staff
                                  ? "#1890ff"
                                  : "#52c41a",
                                marginRight: message.is_staff ? "12px" : 0,
                                marginLeft: message.is_staff ? 0 : "12px",
                              }}
                            />
                            <div
                              style={{
                                maxWidth: "70%",
                                padding: "12px",
                                borderRadius: "8px",
                                backgroundColor: message.is_staff
                                  ? "#f0f2f5"
                                  : "#e6f7ff",
                              }}
                            >
                              <div style={{ marginBottom: "4px" }}>
                                <Text strong>{message.user_name}</Text>
                                <Text
                                  type="secondary"
                                  style={{
                                    marginLeft: "8px",
                                    fontSize: "12px",
                                  }}
                                >
                                  {formatDate(message.created_at)}
                                </Text>
                              </div>
                              <Text>{message.content}</Text>
                            </div>
                          </div>
                        ))
                      ) : (
                        <Empty
                          description="No messages yet"
                          image={Empty.PRESENTED_IMAGE_SIMPLE}
                        />
                      )}
                    </div>

                    <div style={{ marginTop: "16px", display: "flex" }}>
                      <TextArea
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type your message here..."
                        autoSize={{ minRows: 2, maxRows: 6 }}
                        style={{ marginRight: "8px" }}
                        disabled={selectedTicket.status === "closed"}
                      />
                      <Button
                        type="primary"
                        icon={<SendOutlined />}
                        onClick={handleSendMessage}
                        disabled={
                          !newMessage.trim() ||
                          isSubmitting ||
                          selectedTicket.status === "closed"
                        }
                        loading={isSubmitting}
                      >
                        Send
                      </Button>
                    </div>
                  </>
                )}
              </Card>
            </Col>
          </Row>
        </div>
      </Loader>

      <Modal
        title="Create New Support Ticket"
        open={isNewTicketModalVisible}
        onCancel={() => setIsNewTicketModalVisible(false)}
        footer={null}
      >
        <Form form={form} layout="vertical" onFinish={handleCreateTicket}>
          <Form.Item
            name="subject"
            label="Subject"
            rules={[{ required: true, message: "Please enter a subject" }]}
          >
            <Input placeholder="Brief description of your issue" />
          </Form.Item>

          <Form.Item
            name="description"
            label="Description"
            rules={[{ required: true, message: "Please describe your issue" }]}
          >
            <TextArea
              placeholder="Provide details about your issue..."
              autoSize={{ minRows: 4, maxRows: 8 }}
            />
          </Form.Item>

          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              loading={isSubmitting}
              block
            >
              Submit Ticket
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}
