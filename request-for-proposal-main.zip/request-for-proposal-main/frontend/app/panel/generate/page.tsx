"use client";
import AntContent from "@/components/AntDesign/AntContent";
import Loader from "@/components/components/general/Loader";
import StepHeader from "@/components/General/StepHeader";
import { useGenerateContext } from "@/lib/providers/GenerateContextProvider";
import { notify } from "@/utils/functions_utils";
import { DynamicRouter, postRequest } from "@/utils/request_utils";
import { ArrowRightOutlined, WarningOutlined } from "@ant-design/icons";
import { Button, Modal, Row, Space, Steps, Typography } from "antd";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import useSWRMutation from "swr/mutation";
import Information from "./(screens)/A_Information";
import Service from "./(screens)/D_Service";
import BusinessCycle from "./(screens)/E_BusinessCycle";
import FunctionalArea from "./(screens)/F_FunctionalArea";
import Review from "./(screens)/Z_Review";

export default function GenerateRenderScreen() {
  const [current, setCurrent] = useState(0);
  const [openModal, setOpenModal] = useState(false);
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const { data: session } = useSession();
  const url = DynamicRouter("project", "generated-rfp");
  const { trigger } = useSWRMutation(url, postRequest);
  const {
    name,
    company_url,
    description,
    value_propositions,
    industry,
    service_ids,
    business_cycle_ids,
    functional_area_ids,
  } = useGenerateContext();

  const onChange = (value: number) => {
    if (current === 0 && (!name || !description)) {
      notify("Please fill all fields before proceeding", "error");
    } else if (current === 1 && service_ids.length <= 0) {
      notify("Please select at least one service", "error");
    } else if (current === 2 && business_cycle_ids.length === 0) {
      notify("Please select at least one business cycle", "error");
    } else if (current === 3 && functional_area_ids.length === 0) {
      notify("Please select at least one functional area", "error");
    } else {
      setCurrent(value);
    }
  };

  const next = () => {
    if (current < steps.length - 1) setCurrent(current + 1);
  };

  const prev = () => {
    if (current > 0) setCurrent(current - 1);
  };

  const steps = [
    { title: "General Information", content: <Information /> },
    { title: "Services", content: <Service /> },
    { title: "Business Cycles", content: <BusinessCycle /> },
    { title: "Functional Area", content: <FunctionalArea /> },
    { title: "Review", content: <Review /> },
  ];

  return (
    <AntContent>
      <Loader isLoading={loading}>
        <div
          style={{ backgroundColor: "#fff", padding: "10px 0", width: "100%" }}
        >
          <div
            style={{
              maxWidth: "100%",
              margin: "0 auto",
              paddingLeft: "60px",
              paddingRight: "20px",
            }}
          >
            <StepHeader title={steps[current].title} />
          </div>
        </div>
        <div
          style={{
            backgroundColor: "#fff",
            width: "100%",
            padding: "10px 0",
          }}
        >
          <div
            style={{
              width: "95%",
              maxWidth: "1200px",
              margin: "0 auto",
              paddingLeft: "0",
            }}
          >
            <Steps
              type="navigation"
              size="small"
              current={current}
              onChange={onChange}
              className="site-navigation-steps"
              items={steps}
            />
          </div>
        </div>
        <div
          style={{
            maxWidth: "100%",
            margin: "20px auto 0",
            paddingLeft: "20px",
          }}
        >
          {steps[current].content}
        </div>
        <div
          style={{
            position: "fixed",
            bottom: 0,
            left: "70px",
            right: 0,
            backgroundColor: "#fff",
            boxShadow: "0 -2px 10px rgba(0, 0, 0, 0.1)",
            padding: "15px",
            zIndex: 1000,
            borderRadius: "8px 8px 0 0",
          }}
        >
          <div
            style={{
              maxWidth: "1300px",
              margin: "0 auto",
              display: "flex",
              justifyContent: "flex-end",
              paddingLeft: "90px",
              paddingRight: "20px",
            }}
          >
            <Space>
              {current > 0 && (
                <Button
                  type="default"
                  variant="solid"
                  style={{ marginRight: "8px" }}
                  onClick={prev}
                >
                  Previous
                </Button>
              )}
              {current < steps.length - 1 ? (
                <Button
                  type="primary"
                  style={{ backgroundColor: "#626dcf" }}
                  icon={<ArrowRightOutlined />}
                  onClick={() => {
                    if (current === 0 && (!name || !description)) {
                      notify("Please fill all fields", "error");
                    } else if (current === 1 && service_ids.length <= 0) {
                      notify("Please select at least one service", "error");
                    } else if (
                      current === 2 &&
                      business_cycle_ids.length === 0
                    ) {
                      notify(
                        "Please select at least one business cycle",
                        "error"
                      );
                    } else if (
                      current === 3 &&
                      functional_area_ids.length === 0
                    ) {
                      notify(
                        "Please select at least one functional area",
                        "error"
                      );
                    } else {
                      next();
                    }
                  }}
                />
              ) : (
                <Button
                  type="primary"
                  onClick={() => {
                    setLoading(true);
                    const values = {
                      rfp_name: name,
                      rfp_description: description,
                      company_url: company_url,
                      value_propositions: value_propositions,
                      user: session?.user?.id,
                      industry: industry.id,
                      services: service_ids.map((item) => item.id),
                      business_cycles: business_cycle_ids.map(
                        (item) => item.id
                      ),
                      areas: functional_area_ids.map((item) => item.id),
                    };
                    trigger(values, {
                      onSuccess: (response) => {
                        if (response.statusCode === 200) {
                          notify(response.message, "success");
                          const id = response.data.id;
                          router.push(`/panel/generate/export?id=${id}`);
                        } else {
                          notify(response.message, "error");
                        }
                        setLoading(false);
                      },
                    });
                  }}
                >
                  Generate RFP
                </Button>
              )}
            </Space>
          </div>
        </div>
        <Modal
          open={openModal}
          footer={null}
          onCancel={() => setOpenModal(false)}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <WarningOutlined
              style={{ color: "red", fontSize: 50, textAlign: "center" }}
            />
          </div>
          <Typography.Title level={4} style={{ textAlign: "center" }}>
            Are you sure to cancel your process?
          </Typography.Title>
          <Typography.Paragraph style={{ textAlign: "center" }}>
            You will lose all your data if you cancel this process. Please make
            sure you have saved your data before you cancel this process.
          </Typography.Paragraph>
          <Row justify={"center"}>
            <Space>
              <Button onClick={() => setOpenModal(false)}>Cancel</Button>
              <Button
                type="primary"
                danger
                onClick={() => {
                  router.push("/");
                }}
              >
                Yes, I accept!
              </Button>
            </Space>
          </Row>
        </Modal>
      </Loader>
    </AntContent>
  );
}
