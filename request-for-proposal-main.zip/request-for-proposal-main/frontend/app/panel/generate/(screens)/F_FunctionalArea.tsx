import { useGenerateContext } from "@/lib/providers/GenerateContextProvider";
import { ApiResponse } from "@/types/general_types";
import { DynamicRouter, postRequest, makeRequest } from "@/utils/request_utils";
import { notify } from "@/utils/functions_utils";
import {
  SearchOutlined,
  ExpandAltOutlined,
  CompressOutlined,
  PlusOutlined,
  DeleteOutlined,
  EditOutlined,
} from "@ant-design/icons";
import {
  Col,
  Input,
  Row,
  Select,
  Skeleton,
  Table,
  Tabs,
  Typography,
  Button,
  Card,
  Space,
  Divider,
  Modal,
  Form,
  notification,
} from "antd";
import { ColumnsType } from "antd/es/table";
import { useEffect, useState, useRef } from "react";
import useSWR, { useSWRConfig } from "swr";
import useSWRMutation from "swr/mutation";
import { useSession } from "next-auth/react";
import ChatBot from "../../(components)/ChatBot";
import { Tag } from "antd";

const { TabPane } = Tabs;
const { Option } = Select;
const { Title, Text, Paragraph } = Typography;

interface FunctionalArea {
  id: number;
  name: string;
  description: string;
  business_cycle_id: number;
}

interface TableItem {
  id: number;
  name: string;
  description: string;
  priority?: string;
  business_cycle_id: number;
  order?: number;
}

export default function FunctionalAreaTable() {
  const { data: session } = useSession();
  const {
    business_cycle_ids,
    setBusinessCycle_ids,
    functional_area_ids,
    setFunctionalArea_ids,
    setSelectedFunctionalAreas,
  } = useGenerateContext();

  const defaultCycle = business_cycle_ids[0] || null;
  const [selectedCycle, setSelectedCycle] = useState(defaultCycle);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRows, setSelectedRows] = useState<any[]>([]);
  const [priorityValues, setPriorityValues] = useState<Record<string, string>>(
    {}
  );
  const chatBotRef = useRef<any>(null);
  const [tableSize, setTableSize] = useState<"small" | "middle" | "large">(
    "middle"
  );
  const [expandedView, setExpandedView] = useState(false);
  const [expandedRowKeys, setExpandedRowKeys] = useState<string[]>([]);
  const [viewModalVisible, setViewModalVisible] = useState(false);
  const [currentItem, setCurrentItem] = useState<TableItem | null>(null);
  const [showAddNewFA, setShowAddNewFA] = useState(false);
  const [addFAForm] = Form.useForm();
  const [isDeleteModalVisible, setIsDeleteModalVisible] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<TableItem | null>(null);
  const { mutate } = useSWRConfig();

  const url = DynamicRouter("project", "functional-area");
  const customUrl = DynamicRouter("project", "custom-functional-area");
  const {
    data,
    isLoading,
    mutate: mutateData,
  } = useSWR<ApiResponse<any>>(
    session?.user?.organization_id
      ? `${url}?organization_id=${session.user.organization_id}`
      : url
  );
  const { trigger: addFunctionalArea, isMutating: isSubmitting } =
    useSWRMutation(url, postRequest);
  const { trigger: addCustomFunctionalArea, isMutating: isSubmittingCustom } =
    useSWRMutation(customUrl, postRequest);
  const [displayedFunctionalAreas, setDisplayedFunctionalAreas] = useState<any>(
    []
  );

  useEffect(() => {
    if (data?.data && selectedCycle) {
      const filteredFunctionalAreas = data.data.filter(
        (item: any) => item.business_cycle_id === selectedCycle.id
      );

      // Set all records to medium priority
      const areasWithMediumPriority = filteredFunctionalAreas.map(
        (area: any) => ({
          ...area,
          priority: "medium",
        })
      );

      setDisplayedFunctionalAreas(areasWithMediumPriority);

      // Update priority values state
      const newPriorityValues: Record<string, string> = {};
      areasWithMediumPriority.forEach((area: any) => {
        newPriorityValues[area.id] = "medium";
      });
      setPriorityValues(newPriorityValues);
    }
    if (!selectedCycle && business_cycle_ids.length > 0) {
      setSelectedCycle(business_cycle_ids[0]);
    }
  }, [data, selectedCycle, business_cycle_ids]);

  const handlePriorityChange = (value: string, record: any) => {
    setPriorityValues((prev) => ({
      ...prev,
      [record.id]: value,
    }));

    setSelectedRows((prevRows) => {
      const updatedRows = prevRows.map((row) =>
        row.id === record.id ? { ...row, priority: value } : row
      );
      setSelectedFunctionalAreas(updatedRows);
      setFunctionalArea_ids(updatedRows);
      return updatedRows;
    });
  };

  const rowSelection = {
    selectedRowKeys: selectedRows.map((row) => row.id),
    onChange: (selectedRowKeys: any[], selectedRows: any[]) => {
      const updatedRows = selectedRows.map((row) => ({
        ...row,
        priority: priorityValues[row.id] || "medium", // Default to medium
        business_cycle_id: selectedCycle?.id,
      }));

      setSelectedRows(updatedRows);
      setSelectedFunctionalAreas(updatedRows);
      setFunctionalArea_ids(updatedRows);
    },
  };

  const handleTabChange = (key: string) => {
    const cycle = business_cycle_ids.find((cycle) => cycle.name === key);
    setSelectedCycle(cycle || null);

    // When tab changes, we can trigger the chatbot to get AI-generated data
    if (cycle) {
      // You could pass a message to the ChatBot component to request AI data for this cycle
      const message = `Please suggest functional areas for the ${cycle.name} business cycle`;

      // The ChatBot component would need to expose a method to handle this request
      // and update displayedFunctionalAreas with the AI-generated data
      if (chatBotRef.current && chatBotRef.current.requestAIData) {
        chatBotRef.current.requestAIData(cycle);
      }
    }
  };

  // Function to update table data with AI-generated content
  const updateTableWithAIData = (aiGeneratedData: any[]) => {
    if (aiGeneratedData && aiGeneratedData.length > 0) {
      // Merge AI data with existing data or replace it completely
      const updatedData = [...displayedFunctionalAreas];

      // Add new items from AI that don't exist in current data
      aiGeneratedData.forEach((aiItem) => {
        const exists = updatedData.some((item) => item.name === aiItem.name);
        if (!exists) {
          updatedData.push({
            ...aiItem,
            id: `ai-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            business_cycle_id: selectedCycle?.id,
            priority: "medium", // Set priority to medium for new AI-generated items
          });
        }
      });

      // Update priority values for new items
      const newPriorityValues = { ...priorityValues };
      updatedData.forEach((item) => {
        if (!newPriorityValues[item.id]) {
          newPriorityValues[item.id] = "medium";
        }
      });

      setPriorityValues(newPriorityValues);
      setDisplayedFunctionalAreas(updatedData);

      // Save the extracted data
      setSelectedFunctionalAreas(updatedData);
      setFunctionalArea_ids(updatedData);
    }
  };

  const toggleExpandedView = () => {
    setExpandedView(!expandedView);
  };

  const showViewModal = (record: TableItem) => {
    setCurrentItem(record);
    setViewModalVisible(true);
  };

  const handleViewModalClose = () => {
    setViewModalVisible(false);
    setCurrentItem(null);
  };

  const toggleAddFAModal = () => {
    setShowAddNewFA(!showAddNewFA);
    if (!showAddNewFA) {
      addFAForm.resetFields();
    }
  };

  const handleAddFA = async () => {
    try {
      const values = await addFAForm.validateFields();

      if (!selectedCycle || !selectedCycle.id) {
        notification.error({
          message: "Error",
          description: "Please select a business cycle first",
        });
        return;
      }

      if (!session?.user?.organization_id) {
        notification.error({
          message: "Error",
          description: "Organization ID is missing. Please log in again.",
        });
        return;
      }

      const newFA = {
        name: values.name,
        description: values.description,
        business_cycle_id: selectedCycle.id,
        order: 1,
        organization_id: session.user.organization_id,
      };

      const response = await addCustomFunctionalArea(newFA);

      if (response && response.status === "success") {
        const addedFA = {
          ...response.data,
          priority: "medium",
        };

        setDisplayedFunctionalAreas([...displayedFunctionalAreas, addedFA]);
        setPriorityValues({
          ...priorityValues,
          [addedFA.id]: "medium",
        });

        toggleAddFAModal();
        notification.success({
          message: "Success",
          description: "Custom Functional Area added successfully",
        });

        mutateData();
      } else {
        notification.error({
          message: "Error",
          description:
            response?.message || "Failed to add Custom Functional Area",
        });
      }
    } catch (error: any) {
      notification.error({
        message: "Error",
        description:
          error?.message ||
          "Failed to add Custom Functional Area. Please try again.",
      });
    }
  };

  const handleDelete = async (record: TableItem) => {
    setSelectedRecord(record);
    setIsDeleteModalVisible(true);
  };

  const handleDeleteRequest = async (url: string, { arg }: { arg: any }) => {
    try {
      const response = await makeRequest("DELETE", url, arg);
      if (response.status === "success") {
        notification.success({
          message: "Success",
          description: "Functional area deleted successfully",
        });
      } else {
        throw new Error(response.message || "Failed to delete functional area");
      }
      return response;
    } catch (error: any) {
      notification.error({
        message: "Error",
        description: error.message || "An error occurred during deletion",
      });
      throw error;
    }
  };

  const handleUpdateRequest = async (url: string, { arg }: { arg: any }) => {
    try {
      const response = await makeRequest("PUT", url, arg);
      if (response.status === "success") {
        notification.success({
          message: "Success",
          description: "Functional area updated successfully",
        });
      } else {
        throw new Error(response.message || "Failed to update functional area");
      }
      return response;
    } catch (error: any) {
      notification.error({
        message: "Error",
        description: error.message || "An error occurred during update",
      });
      throw error;
    }
  };

  const { trigger: deleteFA } = useSWRMutation(url, handleDeleteRequest);
  const { trigger: updateFA } = useSWRMutation(url, handleUpdateRequest);

  const confirmDelete = async () => {
    if (!selectedRecord) return;

    try {
      const deleteUrl = `${url}${selectedRecord.id}/`; // Fix: Ensure proper slash handling
      const response = await makeRequest("DELETE", deleteUrl, { arg: {} });
      console.log("Delete Response:", response);

      // Refresh data
      mutateData();

      notification.success({
        message: "Success",
        description: "Functional area deleted successfully",
      });
    } catch (error) {
      console.error("Delete Error:", error); // Add logging
      notification.error({
        message: "Error",
        description: "Failed to delete functional area",
      });
    } finally {
      setIsDeleteModalVisible(false);
      setSelectedRecord(null);
    }
  };

  const handleEdit = (record: TableItem) => {
    showViewModal(record);
  };

  // Update columns definition
  const columns: ColumnsType<TableItem> = [
    {
      title: "Functional Area",
      dataIndex: "name",
      key: "name",
      width: 200,
      sorter: (a: TableItem, b: TableItem) => a.name.localeCompare(b.name),
      filterSearch: true,
      filters: displayedFunctionalAreas.map((area: FunctionalArea) => ({
        text: area.name,
        value: area.name,
      })),
      onFilter: (value: any, record: TableItem) => record.name.includes(value),
      render: (text, record) => (
        <Text
          strong
          style={{
            fontSize:
              tableSize === "large"
                ? "16px"
                : tableSize === "small"
                ? "12px"
                : "14px",
          }}
        >
          {text}
        </Text>
      ),
    },
    {
      title: "Functionality Description",
      dataIndex: "description",
      key: "description",
      render: (text) => (
        <Text
          style={{
            fontSize:
              tableSize === "large"
                ? "16px"
                : tableSize === "small"
                ? "12px"
                : "14px",
          }}
        >
          {text.length > 100 ? `${text.substring(0, 100)}...` : text}
        </Text>
      ),
    },
    {
      title: "Priority",
      dataIndex: "priority",
      key: "priority",
      filters: [
        { text: "High", value: "high" },
        { text: "Medium", value: "medium" },
        { text: "Low", value: "low" },
      ],
      onFilter: (value: any, record: TableItem) => {
        const currentPriority = priorityValues[record.id] || "medium";
        return currentPriority === value;
      },
      sorter: (a: TableItem, b: TableItem) => {
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        const priorityA = priorityValues[a.id] || "medium";
        const priorityB = priorityValues[b.id] || "medium";
        return (
          priorityOrder[priorityA as keyof typeof priorityOrder] -
          priorityOrder[priorityB as keyof typeof priorityOrder]
        );
      },
      render: (text: string, record: TableItem) => {
        const value = priorityValues[record.id] || text || "medium";
        const colors = {
          low: { bg: "#f0f9f0", text: "green" },
          medium: { bg: "#fff7e6", text: "orange" },
          high: { bg: "#fff1f0", text: "red" },
        };

        return (
          <Select
            value={value}
            onChange={(value) => handlePriorityChange(value, record)}
            className={`priority-select ${value}`}
            style={{
              width: 120,
              backgroundColor: colors[value as keyof typeof colors].bg,
              color: colors[value as keyof typeof colors].text,
              borderColor: colors[value as keyof typeof colors].text,
              fontSize:
                tableSize === "large"
                  ? "16px"
                  : tableSize === "small"
                  ? "12px"
                  : "14px",
            }}
          >
            <Option
              value="low"
              className="priority-option"
              style={{ backgroundColor: "#f0f9f0", color: "green" }}
            >
              Low
            </Option>
            <Option
              value="medium"
              className="priority-option"
              style={{ backgroundColor: "#fff7e6", color: "orange" }}
            >
              Medium
            </Option>
            <Option
              value="high"
              className="priority-option"
              style={{ backgroundColor: "#fff1f0", color: "red" }}
            >
              High
            </Option>
          </Select>
        );
      },
    },
    {
      title: "Actions",
      key: "actions",
      width: 120,
      render: (_, record) => (
        <Space>
          <Button
            type="text"
            icon={<EditOutlined style={{ fontSize: "18px" }} />}
            onClick={() => handleEdit(record)}
            title="Edit"
            size="large"
          />
          <Button
            type="text"
            danger
            icon={<DeleteOutlined style={{ fontSize: "18px" }} />}
            onClick={() => handleDelete(record)}
            title="Delete"
            size="large"
          />
        </Space>
      ),
    },
  ];

  // Update view modal to include edit functionality
  const handleUpdateRecord = async (values: any) => {
    try {
      if (!currentItem?.id) {
        throw new Error("Record ID is missing");
      }

      const updateUrl = `${url}${currentItem.id}/`;
      console.log("Update URL:", updateUrl);

      const updateData = {
        name: values.name,
        description: values.description,
        business_cycle_id: currentItem.business_cycle_id,
        order: currentItem.order || 1, // Use default value of 1 if order is not provided
      };

      await makeRequest("PUT", updateUrl, { arg: updateData });

      // Güncellemeden sonra tabloyu yenile
      await mutateData();

      notification.success({
        message: "Success",
        description: "Functional area updated successfully",
      });
      handleViewModalClose();
    } catch (error) {
      console.error("Update Error:", error);
      notification.error({
        message: "Error",
        description: "Failed to update functional area",
      });
    }
  };

  const [editForm] = Form.useForm(); // Form instance'ını en üstte tanımla

  // useEffect ekleyin - currentItem değiştiğinde form değerlerini güncelle
  useEffect(() => {
    if (currentItem && editForm) {
      editForm.setFieldsValue({
        name: currentItem.name,
        description: currentItem.description,
      });
    }
  }, [currentItem, editForm]);

  return (
    <div
      style={{
        padding: "20px",
        maxWidth: "100%",
        overflowX: "auto",
        paddingLeft: expandedView ? "20px" : "60px",
      }}
      className="functional-area-container"
    >
      <Row>
        <Col span={expandedView ? 24 : 16}>
          <Card
            className="main-card"
            title={
              <Row justify="space-between" align="middle">
                <Col>
                  <Title level={3} style={{ margin: 0 }}>
                    Functional Areas
                  </Title>
                </Col>
                <Space>
                  <Button
                    icon={<PlusOutlined />}
                    onClick={toggleAddFAModal}
                    style={{ marginRight: "4px" }}
                  >
                    Add New Functional Area
                  </Button>
                  <Button
                    style={{ marginRight: "16px" }}
                    icon={
                      expandedView ? (
                        <CompressOutlined />
                      ) : (
                        <ExpandAltOutlined />
                      )
                    }
                    onClick={toggleExpandedView}
                    title={expandedView ? "Collapse view" : "Expand view"}
                  />
                </Space>
              </Row>
            }
          >
            <Tabs
              defaultActiveKey={defaultCycle?.name || ""}
              onChange={handleTabChange}
              style={{ marginBottom: "16px" }}
              type="card"
              size={tableSize === "small" ? "small" : "middle"}
            >
              {business_cycle_ids.map((cycle) => (
                <TabPane tab={cycle.name} key={cycle.name} />
              ))}
            </Tabs>

            <Row gutter={[16, 16]} style={{ marginBottom: "16px" }}>
              <Col flex="auto">
                <Input
                  placeholder="Search functional areas"
                  prefix={<SearchOutlined />}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  style={{
                    borderRadius: "6px",
                  }}
                  size={
                    tableSize === "small"
                      ? "small"
                      : tableSize === "large"
                      ? "large"
                      : "middle"
                  }
                />
              </Col>
            </Row>

            <Table
              rowSelection={rowSelection}
              columns={columns}
              dataSource={displayedFunctionalAreas.filter((area: any) =>
                area.name.toLowerCase().includes(searchTerm.toLowerCase())
              )}
              pagination={{
                pageSize:
                  tableSize === "small" ? 10 : tableSize === "large" ? 5 : 7,
              }}
              rowKey="id"
              className="custom-table"
              size={tableSize}
              style={{
                border: "1px solid #EAEAEA",
                borderRadius: "8px",
              }}
              scroll={{
                x: "max-content",
                y:
                  tableSize === "small"
                    ? 600
                    : tableSize === "large"
                    ? 400
                    : 500,
              }}
            />
          </Card>
        </Col>
        <Col
          span={expandedView ? 24 : 8}
          style={{ paddingTop: expandedView ? "16px" : "0" }}
        >
          <ChatBot
            ref={chatBotRef}
            displayedFunctionalAreas={displayedFunctionalAreas}
            setDisplayedFunctionalAreas={setDisplayedFunctionalAreas}
            selectedCycle={selectedCycle}
            updateTableWithAIData={updateTableWithAIData}
          />
        </Col>
      </Row>

      {/* Add New Functional Area Modal */}
      <Modal
        title="Add New Functional Area"
        open={showAddNewFA}
        onCancel={toggleAddFAModal}
        footer={[
          <Button key="cancel" onClick={toggleAddFAModal} type="default">
            Cancel
          </Button>,
          <Button
            key="submit"
            type="primary"
            onClick={handleAddFA}
            loading={isSubmittingCustom}
            htmlType="button"
            disabled={!selectedCycle}
          >
            Add Functional Area
          </Button>,
        ]}
        className="custom-modal"
      >
        <Form form={addFAForm} layout="vertical" onFinish={handleAddFA}>
          <Form.Item
            name="name"
            label="Name"
            rules={[{ required: true, message: "Please enter a name" }]}
          >
            <Input placeholder="Enter functional area name" />
          </Form.Item>
          <Form.Item
            name="description"
            label="Description"
            rules={[{ required: true, message: "Please enter a description" }]}
          >
            <Input.TextArea
              placeholder="Enter functional area description"
              rows={4}
            />
          </Form.Item>
          <Form.Item label="Business Cycle">
            <Text
              strong
              style={{ color: selectedCycle ? "inherit" : "#ff4d4f" }}
            >
              {selectedCycle?.name ||
                "Please select a business cycle from the tabs"}
            </Text>
            <Paragraph type="secondary">
              {selectedCycle
                ? "The functional area will be added to the currently selected business cycle."
                : "You must select a business cycle before adding a functional area."}
            </Paragraph>
          </Form.Item>
        </Form>
      </Modal>

      {/* View Details Modal */}
      <Modal
        title={<Title level={4}>{currentItem?.name}</Title>}
        open={viewModalVisible}
        onCancel={handleViewModalClose}
        footer={[
          <Button key="close" onClick={handleViewModalClose}>
            Cancel
          </Button>,
          <Button key="update" type="primary" onClick={() => editForm.submit()}>
            Update
          </Button>,
        ]}
        width={700}
      >
        {currentItem && (
          <div>
            <Card bordered={false}>
              <Form
                form={editForm}
                onFinish={handleUpdateRecord}
                layout="vertical"
                initialValues={{
                  name: currentItem.name,
                  description: currentItem.description,
                }}
              >
                <Form.Item
                  name="name"
                  label="Name"
                  rules={[{ required: true, message: "Please enter name" }]}
                >
                  <Input />
                </Form.Item>
                <Form.Item
                  name="description"
                  label="Description"
                  rules={[
                    { required: true, message: "Please enter description" },
                  ]}
                >
                  <Input.TextArea rows={4} />
                </Form.Item>
              </Form>
            </Card>
          </div>
        )}
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        title="Delete Functional Area"
        open={isDeleteModalVisible}
        onOk={confirmDelete}
        onCancel={() => {
          setIsDeleteModalVisible(false);
          setSelectedRecord(null);
        }}
        okText="Delete"
        cancelText="Cancel"
        okButtonProps={{ danger: true }}
      >
        <p>Are you sure you want to delete this functional area?</p>
      </Modal>
    </div>
  );
}
