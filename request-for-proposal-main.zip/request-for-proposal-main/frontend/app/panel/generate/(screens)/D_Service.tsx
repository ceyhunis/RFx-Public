import React, { useState, useEffect } from "react";
import {
  Button,
  Card,
  Col,
  Input,
  Modal,
  Radio,
  Row,
  Skeleton,
  Pagination,
  Empty,
} from "antd";
import { useGenerateContext } from "@/lib/providers/GenerateContextProvider";
import { ApiResponse } from "@/types/general_types";
import { DynamicRouter, fetcher, postRequest } from "@/utils/request_utils";
import useSWR from "swr";
import { PlusOutlined } from "@ant-design/icons";
import useSWRMutation from "swr/mutation";
import { notify } from "@/utils/functions_utils";
import { useSession } from "next-auth/react";

export default function Service() {
  const { service_ids, setService_ids } = useGenerateContext();
  const [searchTerm, setSearchTerm] = useState("");
  const [displayedData, setDisplayedData] = useState([]);
  const { data: session } = useSession();

  const userId = session?.user?.id;
  console.log("Session Data : ", session);

  const organizationId = session?.user?.organization_id;
  console.log("Organization ID Data : ", organizationId);

  const servicesUrl = organizationId
    ? DynamicRouter("project", `custom-service/${organizationId}`)
    : null;
  const { data: servicesData, error: servicesError } =
    useSWR<ApiResponse<any>>(servicesUrl);

  const [open, setOpen] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [newService, setNewService] = useState({ name: "", description: "" });

  const { trigger } = useSWRMutation(servicesUrl, postRequest);

  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 12;
  const [filteredTotal, setFilteredTotal] = useState(0);

  // Custom service için yeni URL ve trigger tanımlama
  const { trigger: customServiceTrigger } = useSWRMutation(
    servicesUrl,
    postRequest
  );

  const showModal = () => {
    setOpen(true);
  };

  const handleOk = async () => {
    setConfirmLoading(true);
    try {
      const response = await customServiceTrigger({
        ...newService,
        user_id: userId,
        organization_id: organizationId,
      });
      if (response.statusCode === 200) {
        notify("Custom service created successfully", "success");
        setNewService({ name: "", description: "" });
      } else {
        notify(response.message, "error");
      }
    } catch (error) {
      notify("Error occurred while creating service", "error");
    } finally {
      setOpen(false);
      setConfirmLoading(false);
    }
  };

  const handleCancel = () => {
    setOpen(false);
  };

  useEffect(() => {
    if (servicesData?.data) {
      const filteredData: any = searchTerm
        ? servicesData.data.filter((item: any) =>
            item.name.toLowerCase().includes(searchTerm.toLowerCase())
          )
        : servicesData.data;

      setFilteredTotal(filteredData.length);

      const startIndex = (currentPage - 1) * pageSize;
      const endIndex = startIndex + pageSize;
      setDisplayedData(filteredData.slice(startIndex, endIndex));
    }
  }, [servicesData, searchTerm, currentPage]);

  const handleServiceSelection = (item: any) => {
    const isSelected = service_ids.some((service) => service.id === item.id);

    if (isSelected) {
      setService_ids(service_ids.filter((service) => service.id !== item.id));
    } else {
      setService_ids([
        ...service_ids,
        {
          id: item.id,
          name: item.name,
          description: item.description,
        },
      ]);
    }
  };

  const SelectedServices = () => {
    if (service_ids.length === 0) return null;

    return (
      <div
        style={{
          marginTop: "10px",
          overflow: "scroll",
          maxHeight: `calc(100vh - 150px)`,
        }}
      >
        <p
          style={{ fontSize: "16px", fontWeight: "bold", marginBottom: "10px" }}
        >
          Selected Services:
        </p>
        <Row gutter={[16, 16]}>
          {service_ids.map((service) => (
            <Col key={service.id} xs={24}>
              <Card
                size="small"
                style={{
                  borderColor: "#626dcf",
                  backgroundColor: "#f8f9ff",
                }}
              >
                <Card.Meta
                  title={service.name}
                  description={service.description}
                />
              </Card>
            </Col>
          ))}
        </Row>
      </div>
    );
  };

  if (!servicesData) {
    return <Skeleton.Input active />;
  }

  return (
    <div
      className="service-container"
      style={{
        width: "95%",
        margin: "0 auto",
        padding: "10px",
        maxWidth: "1200px", // Ana kapsayıcı maksimum genişliği
      }}
    >
      <Row gutter={[16, 16]}>
        {" "}
        {/* gutter değerini küçülttük */}
        {/* Sol taraf - Ana servis listesi */}
        <Col xs={24} lg={16}>
          <Card bordered={false}>
            <Row gutter={[16, 16]} style={{ marginBottom: "20px" }}>
              <Col xs={24} md={8}>
                <Button
                  size="middle"
                  type="default"
                  icon={<PlusOutlined />}
                  style={{
                    borderColor: "#626dcf",
                    color: "#626dcf",
                    width: "100%",
                    marginTop: "3px",
                  }}
                  onClick={showModal}
                >
                  Generate Custom Service
                </Button>
              </Col>
              <Col xs={24} md={16}>
                <Input
                  size="large"
                  placeholder="Search services..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  style={{ width: "100%" }}
                />
              </Col>
            </Row>

            <div style={{ minHeight: "400px", maxHeight: "600px" }}>
              <Row gutter={[16, 16]}>
                {displayedData.length === 0 ? (
                  <Col span={24}>
                    <Empty description="No services found" />
                  </Col>
                ) : (
                  displayedData.map((item: any) => (
                    <Col key={item.id} xs={24} sm={12} lg={8}>
                      <Card
                        size="small"
                        hoverable
                        style={{
                          borderColor: service_ids.some(
                            (service) => service.id === item.id
                          )
                            ? "#626dcf"
                            : "#e8e8e8",
                          backgroundColor: service_ids.some(
                            (service) => service.id === item.id
                          )
                            ? "#f0f2ff"
                            : "#ffffff",
                        }}
                        onClick={() => handleServiceSelection(item)}
                      >
                        <Card.Meta
                          title={
                            <div
                              style={{ display: "flex", alignItems: "center" }}
                            >
                              <Radio
                                checked={service_ids.some(
                                  (service) => service.id === item.id
                                )}
                                style={{ marginRight: 8 }}
                              />
                              <span style={{ fontSize: "14px" }}>
                                {item.name}
                              </span>
                            </div>
                          }
                          description={
                            <div style={{ marginLeft: 22, fontSize: "12px" }}>
                              {item.description}
                            </div>
                          }
                        />
                      </Card>
                    </Col>
                  ))
                )}
              </Row>
            </div>

            <Row justify="center" style={{ marginTop: "24px" }}>
              <Pagination
                current={currentPage}
                onChange={setCurrentPage}
                total={filteredTotal}
                pageSize={pageSize}
                showSizeChanger={false}
              />
            </Row>
          </Card>
        </Col>
        {/* Sağ taraf - Seçili servisler */}
        <Col xs={24} lg={8}>
          <Card
            title="Selected Services"
            bordered={false}
            bodyStyle={{
              padding: "12px",
              maxHeight: "600px",
              overflowY: "auto",
            }}
          >
            {service_ids.length === 0 ? (
              <Empty description="No services selected" />
            ) : (
              <Row gutter={[0, 12]}>
                {service_ids.map((service) => (
                  <Col key={service.id} span={24}>
                    <Card
                      size="small"
                      hoverable
                      style={{
                        borderColor: "#626dcf",
                        backgroundColor: "#f8f9ff",
                        cursor: "pointer",
                      }}
                      onClick={() => handleServiceSelection(service)}
                    >
                      <Card.Meta
                        title={
                          <div
                            style={{
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "space-between",
                            }}
                          >
                            <span style={{ fontSize: "14px" }}>
                              {service.name}
                            </span>
                            <span
                              style={{ color: "#ff4d4f", fontSize: "12px" }}
                            >
                              X
                            </span>
                          </div>
                        }
                        description={
                          <span style={{ fontSize: "12px" }}>
                            {service.description}
                          </span>
                        }
                      />
                    </Card>
                  </Col>
                ))}
              </Row>
            )}
          </Card>
        </Col>
      </Row>

      <Modal
        title="Add New Custom Service"
        open={open}
        onOk={handleOk}
        confirmLoading={confirmLoading}
        onCancel={handleCancel}
      >
        <Input
          placeholder="Service Name"
          value={newService.name}
          onChange={(e) =>
            setNewService({
              ...newService,
              name: e.target.value,
            })
          }
        />
        <Input.TextArea
          placeholder="Service Description"
          value={newService.description}
          onChange={(e) =>
            setNewService({
              ...newService,
              description: e.target.value,
            })
          }
          rows={4}
          style={{ marginTop: 10 }}
        />
      </Modal>
    </div>
  );
}
