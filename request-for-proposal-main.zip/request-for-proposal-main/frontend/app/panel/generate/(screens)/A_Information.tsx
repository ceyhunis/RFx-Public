import Industry from "@/components/components/industry-choose-area/industry-area";
import { useGenerateContext } from "@/lib/providers/GenerateContextProvider";
import { ApiResponse } from "@/types/general_types";
import { DynamicRouter, postRequest } from "@/utils/request_utils";
import customParseFormat from "dayjs/plugin/customParseFormat";

import GetAIIcon from "@/components/components/icons/GetAiIcon";
import RefactorIcon from "@/components/components/icons/RefactorIcon";
import {
  Button,
  Col,
  DatePicker,
  DatePickerProps,
  Divider,
  Form,
  Input,
  Row,
  Skeleton,
} from "antd";
import dayjs from "dayjs";
import { useEffect, useState } from "react";
import useSWR from "swr";
import useSWRMutation from "swr/mutation";
import Loader from "@/components/components/general/Loader";

dayjs.extend(customParseFormat);

const dateFormat = "DD/MM/YYYY";

const customFormat: DatePickerProps["format"] = (value) =>
  `${value.format(dateFormat)}`;

export default function Information() {
  const urlInformation = DynamicRouter(
    "project",
    "get-information-from-website"
  );
  const { trigger } = useSWRMutation(urlInformation, postRequest);
  const urlRefactorInformation = DynamicRouter(
    "project",
    "refactor-information"
  );
  const { trigger: triggerRefactor } = useSWRMutation(
    urlRefactorInformation,
    postRequest
  );

  const {
    name,
    setName,
    description,
    setDescription,
    company_url,
    setCompanyUrl,
    value_propositions,
    setValuePropositions,

    start_date,
    end_date,
    setStartDate,
    setEndDate,
  } = useGenerateContext();

  const startDateDayjs = start_date ? dayjs(start_date) : null;
  const endDateDayjs = end_date ? dayjs(end_date) : null;

  const [searchTerm, setSearchTerm] = useState("");
  const [displayedData, setDisplayedData] = useState([]);
  const url = DynamicRouter("project", "industry");
  const [isLoading, setIsLoading] = useState(false);
  const { data, error } = useSWR<ApiResponse<any>>(url);

  useEffect(() => {
    if (data?.data) {
      const filteredData: any = searchTerm
        ? data.data.filter((item: any) =>
            item.name.toLowerCase().includes(searchTerm.toLowerCase())
          )
        : data.data.slice(0, 8);
      setDisplayedData(filteredData);
    }
  }, [data, searchTerm]);

  if (!data) {
    return <Skeleton.Input active />;
  }

  const handleGetInformationFromWebsite = () => {
    setIsLoading(true);
    trigger(
      { url: company_url },
      {
        onSuccess: (data) => {
          setValuePropositions(data.data);
          setIsLoading(false);
        },
      }
    );
  };

  const handleRefactorInformation = () => {
    setIsLoading(true);
    triggerRefactor(
      { information: value_propositions },
      {
        onSuccess: (data) => {
          setValuePropositions(data.data);
          setIsLoading(false);
        },
      }
    );
  };

  return (
    <Loader isLoading={isLoading}>
      <Row
        justify="center"
        gutter={32}
        style={{
          width: "100%",
          maxWidth: "1400px",
          margin: "0 auto",
          paddingLeft: "20px",
        }}
      >
        {/* First Column */}
        <Col xs={24} md={12}>
          <Form layout="vertical" style={{ marginTop: 55 }}>
            <Form.Item label={"Document Name"}>
              <Input
                value={name}
                size="large"
                onChange={(e) => setName(e.target.value)}
              />
            </Form.Item>
            <Form.Item label={"Document Description"} style={{ marginTop: 50 }}>
              <Input.TextArea
                style={{ minHeight: 250 }}
                size="large"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </Form.Item>
            <Row gutter={16}>
              <Col xs={24} sm={12}>
                <Form.Item label={"Start Date"}>
                  <DatePicker
                    style={{ width: "100%" }}
                    size="large"
                    format={customFormat}
                    value={startDateDayjs}
                    onChange={(date) =>
                      setStartDate(date ? date.format() : null)
                    }
                    placeholder="Select start date"
                    allowClear
                    showToday
                    disabledDate={(current) => {
                      return endDateDayjs ? current > endDateDayjs : false;
                    }}
                    presets={[
                      { label: "Today", value: dayjs() },
                      { label: "Yesterday", value: dayjs().subtract(1, "d") },
                      { label: "Last Week", value: dayjs().subtract(7, "d") },
                      {
                        label: "Last Month",
                        value: dayjs().subtract(1, "month"),
                      },
                    ]}
                  />
                </Form.Item>
              </Col>
              <Col xs={24} sm={12}>
                <Form.Item label={"End Date"}>
                  <DatePicker
                    style={{ width: "100%" }}
                    size="large"
                    format={customFormat}
                    value={endDateDayjs}
                    onChange={(date) => setEndDate(date ? date.format() : null)}
                    placeholder="Select end date"
                    allowClear
                    showToday
                    disabledDate={(current) => {
                      return startDateDayjs ? current < startDateDayjs : false;
                    }}
                    presets={[
                      { label: "Today", value: dayjs() },
                      { label: "Tomorrow", value: dayjs().add(1, "d") },
                      { label: "Next Week", value: dayjs().add(7, "d") },
                      { label: "Next Month", value: dayjs().add(1, "month") },
                    ]}
                  />
                </Form.Item>
              </Col>
            </Row>
          </Form>
        </Col>

        {/* Second Column with Company Details */}
        <Col xs={24} md={12}>
          <Form layout="vertical">
            <Row gutter={[16, 1]}>
              <Col xs={24}>
                <Form.Item style={{ position: "relative" }}>
                  <Button
                    type="default"
                    style={{
                      position: "absolute",
                      top: 50,
                      right: 0,
                      zIndex: 1,
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                      border: "1px solid #8A2BE2",
                      color: "#8A2BE2",
                      borderRadius: "4px",
                    }}
                    onClick={handleGetInformationFromWebsite}
                  >
                    <GetAIIcon />
                    Get AI Information
                  </Button>
                </Form.Item>

                <Form.Item label={"Company Website (URL)"}>
                  <Input
                    value={company_url}
                    size="large"
                    onChange={(e) => setCompanyUrl(e.target.value)}
                    placeholder="https://example.com"
                  />
                </Form.Item>
              </Col>
              <Col xs={24}>
                <Form.Item style={{ position: "relative" }}>
                  <Button
                    type="default"
                    style={{
                      position: "absolute",
                      top: 50,
                      right: 0,
                      zIndex: 1,
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                      border: "1px solid #8A2BE2",
                      color: "#8A2BE2",
                      borderRadius: "4px",
                    }}
                    onClick={handleRefactorInformation}
                  >
                    <RefactorIcon />
                    Refactor with AI
                  </Button>
                </Form.Item>
                <Form.Item label={"Company Description"}>
                  <Input.TextArea
                    style={{ minHeight: 325 }}
                    size="large"
                    value={value_propositions}
                    onChange={(e) => setValuePropositions(e.target.value)}
                  />
                </Form.Item>
              </Col>
            </Row>
          </Form>
        </Col>
      </Row>

      <Divider />
      <Industry />
      <Divider />
    </Loader>
  );
}
