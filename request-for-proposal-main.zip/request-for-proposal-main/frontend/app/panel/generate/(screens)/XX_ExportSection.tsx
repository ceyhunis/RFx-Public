import StepHeader from "@/components/General/StepHeader";
import { ApiResponse } from "@/types/general_types";
import { notify } from "@/utils/functions_utils";
import { DynamicRouter, postRequest } from "@/utils/request_utils";
import { DownloadOutlined } from '@ant-design/icons';
import {
  Button,
  Col,
  Descriptions,
  Row,
  Skeleton,
  Space,
  Table,
  Tag
} from "antd";
import { useSession } from "next-auth/react";
import { useSearchParams } from "next/navigation";
import { useMemo, useState } from "react";
import { usePDF } from "react-to-pdf";
import useSWR from "swr";
import useSWRMutation from "swr/mutation";
import ChooseCompanyModal from '../components/ChooseCompanyModal';


interface ApiResponseData {
  data: LoadedDataType[];
  message: string;
  status: string;
  statusCode: number;
}

interface LoadedDataType {
  id: number;
  rfp_name: string;
  rfp_description: string;
  company_url: string;
  value_propositions: string;
  industry: number;
  services: number[];
  business_cycles: number[];
  areas: number[];
  descriptions: number[];
}

interface CombinedCycleData {
  cycle_id: number;
  cycle_name: string;
  functional_area: string;
  description: string;
}

interface FunctionalArea {
  id: number;
  name: string;
  description: string;
  priority: string;
  business_cycle_id: number;
}

interface ProcessedDataSource extends LoadedDataType {
  combinedCycleData: CombinedCycleData[];
  functional_areas?: FunctionalArea[];
}

export default function ExportSection() {
  const params = useSearchParams();
  const id = params.get("id");
  const { data: session } = useSession();
  const url = DynamicRouter("project", "data", {
    id: id,
  });
  const { data } = useSWR<ApiResponseData>(url);
  const { toPDF, targetRef } = usePDF({ filename: "page.pdf" });
  const [modalOpen, setModalOpen] = useState(false);
  const sendUrl = DynamicRouter("project", "submitted-rfp");
  const { trigger } = useSWRMutation(sendUrl, postRequest);
  const [loading, setLoading] = useState(false);

  const dataSource = useMemo<ProcessedDataSource | null>(() => {
    if (!data?.data?.[0]) return null;

    const sourceData: LoadedDataType = data.data[0];
    
    return {
      ...sourceData,
      rfp_name: sourceData.rfp_name,
      rfp_description: sourceData.rfp_description,
      company_url: sourceData.company_url,
      value_propositions: sourceData.value_propositions,
      industry: sourceData.industry,
      services: sourceData.services || [],
      business_cycles: sourceData.business_cycles || [],
      areas: sourceData.areas || [],
      descriptions: sourceData.descriptions || []
    } as ProcessedDataSource;
  }, [data]);

  const industryUrl = DynamicRouter("project", "industry", { id: dataSource?.industry });
  const { data: industryData } = useSWR<ApiResponse<any>>(industryUrl);

  const servicesUrl = dataSource?.services && dataSource.services.length > 0 
    ? DynamicRouter("project", "service", { ids: dataSource.services.join(',') })
    : null;
  const { data: servicesData } = useSWR<ApiResponse<any>>(servicesUrl);

  const cyclesUrl = dataSource?.business_cycles && dataSource.business_cycles.length > 0
    ? DynamicRouter("project", "business-cycle")
    : null;
  const { data: cyclesData } = useSWR<ApiResponse<any>>(cyclesUrl);

  const areasUrl = dataSource?.areas && dataSource.areas.length > 0
    ? DynamicRouter("project", "functional-area")
    : null;
  const { data: areasData } = useSWR<ApiResponse<any>>(areasUrl);

  const descriptionsUrl = dataSource?.descriptions && dataSource.descriptions.length > 0
    ? DynamicRouter("project", "description", { ids: dataSource.descriptions.join(',') })
    : null;

  const { data: descriptionsData } = useSWR<ApiResponse<any>>(descriptionsUrl);

  const selectedAreas = useMemo(() => {
    if (!areasData?.data || !dataSource?.areas) return [];
    
    const filtered = areasData.data.filter((area: any) => 
      dataSource.areas.includes(area.id)
    );
    
    return filtered;
  }, [areasData, dataSource]);

  const renderPriorityTag = (priority: string) => {
    if (!priority) return <Tag color="gray">Not Selected</Tag>;
    
    switch (priority.toLowerCase()) {
      case "high":
        return <Tag color="red">High</Tag>;
      case "medium":
        return <Tag color="orange">Medium</Tag>;
      case "low":
        return <Tag color="green">Low</Tag>;
      default:
        return <Tag color="gray">Not Selected</Tag>;
    }
  };

  const mainData = [{
    key: '1',
    documentName: dataSource?.rfp_name,
    documentDescription: dataSource?.rfp_description,
    companyUrl: dataSource?.company_url,
    companyDescription: dataSource?.value_propositions,
    industry: industryData?.data?.[0]?.name,
  }];

  const serviceData = servicesData?.data?.map((service: any, index: number) => ({
    key: `service-${index}`,
    serviceName: service.name,
  })) || [];

  const combinedData = selectedAreas.map((area: any, index: number) => {
    const cycle = cyclesData?.data?.find((c: any) => c.id === area.business_cycle_id);
    const description = descriptionsData?.data?.find((desc: any) => 
      desc.functional_area_id === area.id
    );
    
    return {
      key: `cycle-${index}`,
      cycleName: cycle?.name || 'N/A',
      functionalArea: area.name,
      functionalityDescription: area.description,
      priority: renderPriorityTag(description?.priority || "")
    };
  });

  const mainColumns = [
    { title: "Document Name", dataIndex: "documentName", key: "documentName" },
    { title: "Document Description", dataIndex: "documentDescription", key: "documentDescription" },
    { title: "Company Website (URL)", dataIndex: "companyUrl", key: "companyUrl" },
    { title: "Company Description", dataIndex: "companyDescription", key: "companyDescription" },
    { title: "Industry", dataIndex: "industry", key: "industry" },
  ];

  const combinedColumns = [
    { title: "Business Cycles", dataIndex: "cycleName", key: "cycleName" },
    { title: "Functional Areas", dataIndex: "functionalArea", key: "functionalArea" },
    { title: "Functionality Descriptions", dataIndex: "functionalityDescription", key: "functionalityDescription" },
    { title: "Priority", dataIndex: "priority", key: "priority" },
  ];

  if (!dataSource) {
    return <Skeleton.Input active />;
  }
  return (
    <Row justify="center">
      <Col xs={24}>
        <Row align="middle" justify="space-between" style={{ marginBottom: 20, marginLeft: 110 }}>
          <div style={{ 
            fontSize: '14px',
            marginTop: 20,
            fontWeight: '900', 
            color: '#121BDA'
          }}>
            <StepHeader title="RFP Flow" />
          </div>
        </Row>

        <div ref={targetRef} style={{ padding: 10, marginLeft: 100, marginRight:40 }}>
          <Table
            dataSource={mainData}
            columns={mainColumns}
            pagination={false}
            bordered
            className="general-table"
          />

          <Descriptions bordered className="custom-descriptions">
            {serviceData?.length > 0 && (
              <Descriptions.Item label="SERVICES" span={2}>
                <Row gutter={16}>
                  {serviceData.map((service: any) => (
                    <Col key={service.key} className="borderless-cell">
                      {service.serviceName}
                    </Col>
                  ))}
                </Row>
              </Descriptions.Item>
            )}
          </Descriptions>

          <Table
            dataSource={combinedData}
            columns={combinedColumns}
            pagination={false}
            bordered
            className="business-cycle-table"
          />

          <Row justify="end" style={{ marginTop: 40 }}>
            <Space>
              <Button
                type="primary"
                onClick={() => toPDF()}
                size="large"
                icon={<DownloadOutlined />}
              >
                Export PDF
              </Button>
              <Button 
                type="primary"
                onClick={() => setModalOpen(true)}
                size="large"
              >
                Choose Company
              </Button>
            </Space>
          </Row>
        </div>

        <ChooseCompanyModal
          isOpen={modalOpen}
          onClose={() => setModalOpen(false)}
          loading={loading}
          rfpId={id}
          documentName={dataSource?.rfp_name}
          onSubmit={async (values) => {
            setLoading(true);
            try {
              const response = await trigger(values);
              if (response.statusCode === 200) {
                notify(response.message, "success");
              } else {
                notify(response.message, "error");
              }
            } finally {
              setLoading(false);
              setModalOpen(false);
            }
          }}
        />
      </Col>
    </Row>
  );
}