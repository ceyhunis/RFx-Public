import { useGenerateContext } from "@/lib/providers/GenerateContextProvider";
import { Col, Descriptions, Row, Table, Tag } from "antd";
import React from "react";
import "@/components/css/general.css";

export default function Review() {
  const {
    name,
    description,
    value_propositions,
    company_url,
    service_ids,
    business_cycle_ids,
    industry,
    selectedFunctionalAreas,
  } = useGenerateContext();

  const renderPriorityTag = (priority: string) => {
    switch (priority.toLowerCase()) {
      case "high":
        return <Tag color="red">High</Tag>;
      case "medium":
        return <Tag color="orange">Medium</Tag>;
      case "low":
        return <Tag color="green">Low</Tag>;
      default:
        return <Tag color="gray">Not Selected</Tag>;
    }
  };

  const combinedData = business_cycle_ids.map((cycle, index) => {
    const functionalArea = selectedFunctionalAreas[index] || {};
    return {
      key: `cycle-${index}`,
      cycleName: cycle.name,
      functionalArea: functionalArea.name || "",
      functionalityDescription: functionalArea.description || "",
      priority: renderPriorityTag(functionalArea.priority || ""),
    };
  });

  const data = [
    {
      key: "1",
      documentName: name,
      documentDescription: description,
      companyUrl: company_url,
      companyDescription: value_propositions,
      industry: industry.name,
    },
  ];

  const serviceData = service_ids.map((service, index) => ({
    key: `service-${index}`,
    serviceName: service.name,
  }));

  const columns = [
    { title: "Document Name", dataIndex: "documentName", key: "documentName" },
    {
      title: "Document Description",
      dataIndex: "documentDescription",
      key: "documentDescription",
    },
    {
      title: "Company Website (URL)",
      dataIndex: "companyUrl",
      key: "companyUrl",
    },
    {
      title: "Company Description",
      dataIndex: "companyDescription",
      key: "companyDescription",
    },
    { title: "Industry", dataIndex: "industry", key: "industry" },
  ];

  const serviceColumns = [
    { title: "Services", dataIndex: "serviceName", key: "serviceName" },
  ];

  const combinedColumns = [
    { title: "Business Cycles", dataIndex: "cycleName", key: "cycleName" },
    {
      title: "Functional Areas",
      dataIndex: "functionalArea",
      key: "functionalArea",
    },
    {
      title: "Functionality Descriptions",
      dataIndex: "functionalityDescription",
      key: "functionalityDescription",
    },
    { title: "Priority", dataIndex: "priority", key: "priority" },
  ];

  return (
    <Row justify="center" style={{ maxHeight: "600px" }}>
      <Col xs={24}>
        <Row
          align="middle"
          justify="space-between"
          style={{ marginBottom: 20, marginLeft: 110 }}
        >
          <div
            style={{
              fontSize: "14px",
              fontWeight: "900",
              color: "#121BDA",
            }}
          ></div>
        </Row>

        <div style={{ padding: 10, marginLeft: 100, marginRight: 40 }}>
          <Table
            dataSource={data}
            columns={columns}
            pagination={false}
            bordered
            className="general-table"
          />

          <Descriptions bordered className="custom-descriptions">
            {serviceData?.length > 0 && (
              <Descriptions.Item label="SERVICES" span={2}>
                <Row gutter={16}>
                  {serviceData.map((service) => (
                    <Col key={service.key} className="borderless-cell">
                      {service.serviceName}
                    </Col>
                  ))}
                </Row>
              </Descriptions.Item>
            )}
          </Descriptions>

          <Table
            dataSource={combinedData}
            columns={combinedColumns}
            pagination={false}
            bordered
            className="business-cycle-table"
          />
        </div>
      </Col>
    </Row>
  );
}
