import React, { useState, useEffect } from "react";
import {
  Button,
  Card,
  Col,
  Input,
  Modal,
  Radio,
  Row,
  Skeleton,
  Pagination,
  Empty,
} from "antd";
import { PlusOutlined } from "@ant-design/icons";
import { useGenerateContext } from "@/lib/providers/GenerateContextProvider";
import { ApiResponse } from "@/types/general_types";
import { DynamicRouter, postRequest } from "@/utils/request_utils";
import useSWR from "swr";
import useSWRMutation from "swr/mutation";
import { notify } from "@/utils/functions_utils";
import { useSession } from "next-auth/react";

export default function BusinessCycle() {
  const { business_cycle_ids, setBusinessCycle_ids } = useGenerateContext();
  const [searchTerm, setSearchTerm] = useState("");
  const [displayedData, setDisplayedData] = useState([]);
  const { data: session } = useSession();

  const userId = session?.user?.id;
  const organizationId = session?.user?.organization_id;

  // URL güncelleme - Organizasyona özel business cycle'lar için
  const businessCyclesUrl = organizationId
    ? DynamicRouter("project", `custom-business-cycle/${organizationId}`)
    : null;
  const { data: businessCyclesData, error: businessCyclesError } =
    useSWR<ApiResponse<any>>(businessCyclesUrl);

  const [open, setOpen] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [newBusinessCycle, setNewBusinessCycle] = useState({
    name: "",
    description: "",
  });

  const { trigger } = useSWRMutation(businessCyclesUrl, postRequest);

  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 12;
  const [filteredTotal, setFilteredTotal] = useState(0);

  const showModal = () => {
    setOpen(true);
  };

  const handleOk = async () => {
    setConfirmLoading(true);
    try {
      const response = await trigger({
        ...newBusinessCycle,
        user_id: userId,
        organization_id: organizationId,
      });
      if (response.statusCode === 200) {
        notify("Custom business cycle created successfully", "success");
        setNewBusinessCycle({ name: "", description: "" });
      } else {
        notify(response.message, "error");
      }
    } catch (error) {
      notify("Error occurred while creating business cycle", "error");
    } finally {
      setOpen(false);
      setConfirmLoading(false);
    }
  };

  const handleCancel = () => {
    setOpen(false);
  };

  useEffect(() => {
    if (businessCyclesData?.data) {
      const filteredData: any = searchTerm
        ? businessCyclesData.data.filter((item: any) =>
            item.name.toLowerCase().includes(searchTerm.toLowerCase())
          )
        : businessCyclesData.data;

      setFilteredTotal(filteredData.length);

      const startIndex = (currentPage - 1) * pageSize;
      const endIndex = startIndex + pageSize;
      setDisplayedData(filteredData.slice(startIndex, endIndex));
    }
  }, [businessCyclesData, searchTerm, currentPage]);

  const handleBusinessCycleSelection = (item: any) => {
    const isSelected = business_cycle_ids.some((cycle) => cycle.id === item.id);

    if (isSelected) {
      setBusinessCycle_ids(
        business_cycle_ids.filter((cycle) => cycle.id !== item.id)
      );
    } else {
      setBusinessCycle_ids([
        ...business_cycle_ids,
        {
          id: item.id,
          name: item.name,
          description: item.description,
        },
      ]);
    }
  };

  const SelectedBusinessCycles = () => {
    if (business_cycle_ids.length === 0) return null;

    return (
      <div
        style={{
          marginTop: "10px",
          overflow: "scroll",
          maxHeight: `calc(100vh - 150px)`,
        }}
      >
        <p
          style={{ fontSize: "16px", fontWeight: "bold", marginBottom: "10px" }}
        >
          Selected Business Cycles:
        </p>
        <Row gutter={[16, 16]}>
          {business_cycle_ids.map((cycle) => (
            <Col key={cycle.id} xs={24}>
              <Card
                size="small"
                style={{
                  borderColor: "#626dcf",
                  backgroundColor: "#f8f9ff",
                }}
              >
                <Card.Meta title={cycle.name} description={cycle.description} />
              </Card>
            </Col>
          ))}
        </Row>
      </div>
    );
  };

  if (!businessCyclesData) {
    return <Skeleton.Input active />;
  }

  return (
    <div
      className="businessCycle-container"
      style={{
        width: "95%",
        margin: "0 auto",
        padding: "10px",
        maxWidth: "1200px",
      }}
    >
      <Row gutter={[16, 16]}>
        <Col xs={24} lg={16}>
          <Card bordered={false}>
            <Row gutter={[16, 16]} style={{ marginBottom: "20px" }}>
              <Col xs={24} md={8}>
                <Button
                  size="middle"
                  type="default"
                  icon={<PlusOutlined />}
                  style={{
                    borderColor: "#626dcf",
                    color: "#626dcf",
                    width: "100%",
                    marginTop: "3px",
                  }}
                  onClick={showModal}
                >
                  Custom Business Cycle
                </Button>
              </Col>
              <Col xs={24} md={16}>
                <Input
                  size="large"
                  placeholder="Search"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  style={{ width: "100%" }}
                />
              </Col>
            </Row>

            <div style={{ minHeight: "400px", maxHeight: "600px" }}>
              <Row gutter={[16, 16]}>
                {displayedData.length === 0 ? (
                  <Col span={24}>
                    <Empty description="No business cycles found" />
                  </Col>
                ) : (
                  displayedData.map((item: any) => (
                    <Col key={item.id} xs={24} sm={12} lg={8}>
                      <Card
                        size="small"
                        hoverable
                        style={{
                          borderColor: business_cycle_ids.some(
                            (cycle) => cycle.id === item.id
                          )
                            ? "#626dcf"
                            : "#e8e8e8",
                          backgroundColor: business_cycle_ids.some(
                            (cycle) => cycle.id === item.id
                          )
                            ? "#f0f2ff"
                            : "#ffffff",
                        }}
                        onClick={() => handleBusinessCycleSelection(item)}
                      >
                        <Card.Meta
                          title={
                            <div
                              style={{ display: "flex", alignItems: "center" }}
                            >
                              <Radio
                                checked={business_cycle_ids.some(
                                  (cycle) => cycle.id === item.id
                                )}
                                style={{ marginRight: 8 }}
                              />
                              <span style={{ fontSize: "14px" }}>
                                {item.name}
                              </span>
                            </div>
                          }
                          description={
                            <div style={{ marginLeft: 22, fontSize: "12px" }}>
                              {item.description}
                            </div>
                          }
                        />
                      </Card>
                    </Col>
                  ))
                )}
              </Row>
            </div>

            <Row justify="center" style={{ marginTop: "24px" }}>
              <Pagination
                current={currentPage}
                onChange={setCurrentPage}
                total={filteredTotal}
                pageSize={pageSize}
                showSizeChanger={false}
              />
            </Row>
          </Card>
        </Col>

        {/* Sağ taraf - Seçili business cycles */}
        <Col xs={24} lg={8}>
          <Card
            title="Selected Business Cycles"
            bordered={false}
            bodyStyle={{
              padding: "12px",
              maxHeight: "600px",
              overflowY: "auto",
            }}
          >
            {business_cycle_ids.length === 0 ? (
              <Empty description="No business cycles selected" />
            ) : (
              <Row gutter={[0, 12]}>
                {business_cycle_ids.map((cycle) => (
                  <Col key={cycle.id} span={24}>
                    <Card
                      size="small"
                      hoverable
                      style={{
                        borderColor: "#626dcf",
                        backgroundColor: "#f8f9ff",
                        cursor: "pointer",
                      }}
                      onClick={() => handleBusinessCycleSelection(cycle)}
                    >
                      <Card.Meta
                        title={
                          <div
                            style={{
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "space-between",
                            }}
                          >
                            <span style={{ fontSize: "14px" }}>
                              {cycle.name}
                            </span>
                            <span
                              style={{ color: "#ff4d4f", fontSize: "12px" }}
                            >
                              X
                            </span>
                          </div>
                        }
                        description={
                          <span style={{ fontSize: "12px" }}>
                            {cycle.description}
                          </span>
                        }
                      />
                    </Card>
                  </Col>
                ))}
              </Row>
            )}
          </Card>
        </Col>
      </Row>

      <Modal
        title="Add New Business Cycle"
        open={open}
        onOk={handleOk}
        confirmLoading={confirmLoading}
        onCancel={handleCancel}
      >
        <Input
          placeholder="Business Cycle Name"
          value={newBusinessCycle.name}
          onChange={(e) =>
            setNewBusinessCycle({
              ...newBusinessCycle,
              name: e.target.value,
            })
          }
        />
        <Input.TextArea
          placeholder="Business Cycle Description"
          value={newBusinessCycle.description}
          onChange={(e) =>
            setNewBusinessCycle({
              ...newBusinessCycle,
              description: e.target.value,
            })
          }
          rows={4}
          style={{ marginTop: 10 }}
        />
      </Modal>
    </div>
  );
}
