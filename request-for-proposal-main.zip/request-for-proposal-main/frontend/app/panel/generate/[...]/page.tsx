"use client";
import { usePathname } from "next/navigation";
import React from "react";
import ExportSection from "../(screens)/XX_ExportSection";

export default function ExportPage() {
  const pathname = usePathname();

  if (pathname === "/panel/generate/export") {
    return <ExportSection />;
  }
  return <div>error</div>;
}
