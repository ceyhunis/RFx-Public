import { App as AntdApp } from "antd";
import type { AppProps } from "next/app"; // Import AppProps from next/app

function MyApp({ Component, pageProps }: AppProps) {
  return (
    <AntdApp>
      <Component {...pageProps} />
    </AntdApp>
  );
}

export default MyApp;
