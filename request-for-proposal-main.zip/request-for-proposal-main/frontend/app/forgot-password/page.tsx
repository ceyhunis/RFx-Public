"use client";

import MainFooter from "@/components/components/general/MainFooter";
import MainNavbar from "@/components/components/general/MainNavbar";
import ForgotPasswordHero from "@/components/components/login-page/forgot-password/ForgotPasswordHero";
import { Layout } from "antd";

const { Content, Footer } = Layout;

export default function ForgotPasswordPage() {
  return (
    <Layout style={{ 
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      backgroundColor: "transparent" 
    }}>
      <MainNavbar />
      <Content style={{ 
        padding: "20px 0",
        flex: "1 0 auto" 
      }}>
        <ForgotPasswordHero />
      </Content>
      <Footer style={{ 
        flexShrink: 0,
        marginTop: "auto",
        padding: 0, 
        background: "transparent"
      }}>
        <MainFooter />
      </Footer>
    </Layout>
  );
}
