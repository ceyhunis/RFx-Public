"use client";

import MainFooter from "@/components/components/general/MainFooter";
import MainNavbar from "@/components/components/general/MainNavbar";
import NewPasswordHero from "@/components/components/login-page/new-password/NewPasswordHero";
import { Layout } from "antd";
import { Suspense } from "react";

const { Content, Footer } = Layout;

export default function NewPasswordPage() {
  return (
    <Layout style={{ 
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      backgroundColor: "transparent" 
    }}>
      <MainNavbar />
      <Content style={{ 
        padding: "20px 0",
        flex: "1 0 auto" 
      }}>
        <Suspense fallback={<div>Loading...</div>}>
          <NewPasswordHero />
        </Suspense>
      </Content>
      <Footer style={{ 
        flexShrink: 0,
        marginTop: "auto",
        padding: 0, 
        background: "transparent"
      }}>
        <MainFooter />
      </Footer>
    </Layout>
  );
}
