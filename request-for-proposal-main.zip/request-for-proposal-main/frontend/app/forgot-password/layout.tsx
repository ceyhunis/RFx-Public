import AntLayout from "@/components/AntDesign/AntLayout";
import React from "react";

export default function ForgotPasswordLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <AntLayout>{children}</AntLayout>;
}
