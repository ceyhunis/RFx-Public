"use client";

import React, { useState, useEffect } from "react";
import {
  Table,
  Tabs,
  Select,
  Skeleton,
  Button,
  Tooltip,
  notification,
} from "antd";
import { ApiResponse } from "@/types/general_types";
import { DynamicRouter, makeRequest } from "@/utils/request_utils";
import useSWR from "swr";
import { EditOutlined } from "@ant-design/icons";
import { useRouter } from "next/navigation";

const { TabPane } = Tabs;
const { Option } = Select;

interface FunctionalAreaTableProps {
  searchTerm: string;
  business_cycle_ids: any[];
  setBusinessCycle_ids: (value: any[]) => void;
  functional_area_ids: any[];
  setFunctionalArea_ids: (value: any[]) => void;
  setSelectedFunctionalAreas: (value: any[]) => void;
}

export default function FunctionalAreaTable({
  searchTerm,
  business_cycle_ids,
  setBusinessCycle_ids,
  functional_area_ids,
  setFunctionalArea_ids,
  setSelectedFunctionalAreas,
}: FunctionalAreaTableProps) {
  const router = useRouter();
  const defaultCycle = business_cycle_ids[0] || null;
  const [selectedCycle, setSelectedCycle] = useState(defaultCycle);
  const [selectedRows, setSelectedRows] = useState<any[]>([]);
  const [priorityValues, setPriorityValues] = useState<Record<string, string>>(
    {}
  );
  const [displayedFunctionalAreas, setDisplayedFunctionalAreas] = useState<any>(
    []
  );
  const [currentItem, setCurrentItem] = useState<any>(null);

  const url = DynamicRouter("project", "functional-area");
  const customUrl = DynamicRouter("project", "custom-functional-area");

  const {
    data,
    isLoading,
    mutate: mutateFunctionalAreas,
  } = useSWR<ApiResponse<any>>(
    session?.user?.organization_id
      ? `${customUrl}?organization_id=${session.user.organization_id}`
      : url
  );

  useEffect(() => {
    if (data?.data) {
      const filteredFunctionalAreas = selectedCycle
        ? data.data.filter(
            (item: any) => item.business_cycle_id === selectedCycle.id
          )
        : data.data;

      setDisplayedFunctionalAreas(filteredFunctionalAreas);
    }

    if (!selectedCycle && business_cycle_ids.length > 0) {
      setSelectedCycle(business_cycle_ids[0]);
    }
  }, [data, selectedCycle, business_cycle_ids]);

  const handlePriorityChange = (value: string, record: any) => {
    setPriorityValues((prev) => ({
      ...prev,
      [record.id]: value,
    }));

    setSelectedRows((prevRows) => {
      const updatedRows = prevRows.map((row) =>
        row.id === record.id ? { ...row, priority: value } : row
      );
      setSelectedFunctionalAreas(updatedRows);
      setFunctionalArea_ids(updatedRows);
      return updatedRows;
    });

    mutateFunctionalAreas();
  };

  const handleDelete = async (record: any) => {
    try {
      const deleteUrl = `${record.organization ? customUrl : url}${record.id}/`;
      await makeRequest("DELETE", deleteUrl, {});
      notification.success({
        message: "Success",
        description: "Functional area deleted successfully",
      });

      mutateFunctionalAreas();
    } catch (error) {
      notification.error({
        message: "Error",
        description: "Failed to delete functional area",
      });
    }
  };

  const handleUpdateRecord = async (values: any) => {
    try {
      if (!currentItem?.id) {
        throw new Error("Record ID is missing");
      }

      const updateUrl = `${currentItem.organization ? customUrl : url}${
        currentItem.id
      }/`;
      const updateData = {
        name: values.name,
        description: values.description,
        business_cycle_id: currentItem.business_cycle_id,
        order: currentItem.order || 1,
      };

      await makeRequest("PUT", updateUrl, { arg: updateData });
      notification.success({
        message: "Success",
        description: "Functional area updated successfully",
      });

      mutateFunctionalAreas();
      handleViewModalClose();
    } catch (error) {
      notification.error({
        message: "Error",
        description: "Failed to update functional area",
      });
    }
  };

  const rowSelection = {
    selectedRowKeys: selectedRows.map((row) => row.id),
    onChange: (selectedRowKeys: any[], selectedRows: any[]) => {
      const updatedRows = selectedRows.map((row) => ({
        ...row,
        priority: priorityValues[row.id] || "low",
        business_cycle_id: selectedCycle?.id,
      }));

      setSelectedRows(updatedRows);
      setSelectedFunctionalAreas(updatedRows);
      setFunctionalArea_ids(updatedRows);
    },
  };

  const columns = [
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "Description",
      dataIndex: "description",
      key: "description",
    },
    {
      title: "Priority",
      dataIndex: "priority",
      key: "priority",
      render: (text: string, record: any) => {
        const value = priorityValues[record.id] || text || "low";
        const colors = {
          low: { bg: "#f0f9f0", text: "green" },
          medium: { bg: "#fff7e6", text: "orange" },
          high: { bg: "#fff1f0", text: "red" },
        };

        return (
          <Select
            value={value}
            onChange={(value) => handlePriorityChange(value, record)}
            className={`priority-select ${value}`}
            style={{
              width: 120,
              backgroundColor: colors[value as keyof typeof colors].bg,
              color: colors[value as keyof typeof colors].text,
              borderColor: colors[value as keyof typeof colors].text,
            }}
          >
            <Option
              value="low"
              className="priority-option"
              style={{ backgroundColor: "#f0f9f0", color: "green" }}
            >
              Low
            </Option>
            <Option
              value="medium"
              className="priority-option"
              style={{ backgroundColor: "#fff7e6", color: "orange" }}
            >
              Medium
            </Option>
            <Option
              value="high"
              className="priority-option"
              style={{ backgroundColor: "#fff1f0", color: "red" }}
            >
              High
            </Option>
          </Select>
        );
      },
    },
    {
      title: "Answer",
      dataIndex: "ResponseAnswer",
      key: "ResponseAnswer",
      width: 150,
      render: (text: string, record: any) => {
        const getStatusColor = (answer: string) => {
          switch (answer?.toLowerCase()) {
            case "yes":
              return "#52c41a";
            case "no":
              return "#ff4d4f";
            case "pending":
              return "#faad14";
            default:
              return "#8c8c8c";
          }
        };

        return (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              minWidth: "120px",
            }}
          >
            <div
              style={{
                padding: "2px 8px",
                borderRadius: "4px",
                backgroundColor: text
                  ? getStatusColor(text) + "20"
                  : "transparent",
                color: getStatusColor(text),
                fontSize: "12px",
                width: "60px",
                textAlign: "center",
              }}
            >
              {text || "-"}
            </div>
            <Tooltip title="Edit Answer">
              <Button
                type="text"
                icon={<EditOutlined />}
                style={{
                  color: "#626DCF",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "32px",
                  height: "32px",
                  padding: 0,
                }}
                onClick={() => {
                  router.push(`/response/answer/${record.id}`);
                }}
              />
            </Tooltip>
          </div>
        );
      },
    },
  ];

  if (isLoading) {
    return <Skeleton.Input active />;
  }

  return (
    <>
      <Tabs
        defaultActiveKey={defaultCycle?.name || ""}
        onChange={(key) => {
          const cycle = business_cycle_ids.find((cycle) => cycle.name === key);
          setSelectedCycle(cycle || null);
        }}
        style={{ marginBottom: "20px" }}
        type="card"
      >
        {business_cycle_ids.map((cycle) => (
          <TabPane tab={cycle.name} key={cycle.name} />
        ))}
      </Tabs>

      <Table
        rowSelection={rowSelection}
        columns={columns}
        dataSource={displayedFunctionalAreas.filter((area: any) =>
          area.name.toLowerCase().includes(searchTerm.toLowerCase())
        )}
        pagination={{ pageSize: 5 }}
        rowKey="id"
        className="custom-table"
        style={{
          width: "100%",
          border: "1px solid #EAEAEA",
          borderRadius: "8px",
          overflowX: "auto",
        }}
        scroll={{ x: true }}
      />
    </>
  );
}
