"use client";

import React from "react";
import { Card, Button } from "antd";
import { ArrowLeftOutlined } from "@ant-design/icons";
import { useRouter } from "next/navigation";

export default function AnswerPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  
  return (
    <div style={{ padding: '24px' }}>
      <Button 
        icon={<ArrowLeftOutlined />} 
        style={{ marginBottom: '16px' }}
        onClick={() => router.back()}
      >
        Back
      </Button>
      
      <Card title="Answer Question">
        <p>Question ID: {params.id}</p>
        {/* Burada cevap formu oluşturulacak */}
      </Card>
    </div>
  );
}
