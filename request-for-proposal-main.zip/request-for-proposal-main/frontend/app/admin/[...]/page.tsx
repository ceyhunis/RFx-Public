"use client";

import Loader from "@/components/components/general/Loader";
import { useDrawer } from "@/lib/providers/DrawerContextProvider";
import {
  businessCycleFieldMetaData,
  functionalAreaFieldMetaData,
  industryFieldMetaData,
  organizationFieldMetaData,
  providerFieldMetaData,
  roleFieldMetaData,
  serviceFieldMetaData,
  userFieldMetaData,
} from "@/types/admin_meta_types";
import { ApiResponse, FormMetaType } from "@/types/general_types";
import { notify } from "@/utils/functions_utils";
import { DynamicRouter, fetcher, postRequest } from "@/utils/request_utils";
import {
  Button,
  Divider,
  Drawer,
  Input,
  Modal,
  Row,
  Select,
  Space,
  Typography,
  Form,
} from "antd";
import { useForm } from "antd/es/form/Form";
import { ColumnType } from "antd/es/table";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import useSWR from "swr";
import useSWRMutation from "swr/mutation";
import WrapperCRUDForm from "../(components)/WrapperCRUDForm";
import WrapperTable from "../(components)/WrapperTable";

export default function AdminPage() {
  const [form] = useForm();
  const { isOpen, closeDrawer, openDrawer } = useDrawer();
  const [bulkAction, setBulkAction] = useState();
  const params = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();
  const bulkURL = DynamicRouter("project", "bulk-actions");
  const { trigger } = useSWRMutation(bulkURL, postRequest);
  const fileURL = DynamicRouter("project", "save-with-multi-data");
  const { trigger: triggerFile } = useSWRMutation(fileURL, postRequest);
  const record = {
    id: params.get("id") ?? null,
  };
  const [searchQuery, setSearchQuery] = useState("");
  const [isSupportModalOpen, setIsSupportModalOpen] = useState(false);
  const [supportForm] = Form.useForm();
  const supportURL = DynamicRouter("project", "outseta-support");
  const { trigger: triggerSupport } = useSWRMutation(supportURL, postRequest);

  const handleSearchChange = (e: any) => {
    setSearchQuery(e.target.value);
  };
  const [selectedRowKeys, setSelectedRowKeys] = useState<any[]>([]);
  const onSelectChange = (newSelectedRowKeys: React.Key[]) => {
    setSelectedRowKeys(newSelectedRowKeys);
  };
  const [loading, setLoading] = useState(false);
  const [openPreview, setOpenPreview] = useState(false);
  const [previewedData, setPreviewedData] = useState<any>();
  const [functionalAreaParams, setFunctionalAreaParams] = useState(false);
  const [businessCycle, setBusinessCycle] = useState();

  useEffect(() => {
    if (pathname) {
      setSelectedRowKeys([]);
    }
  }, [pathname]);

  const pathRenderMap: {
    [key: string]: {
      url: string;
      title: string;
      key_word: string;
      metaData: FormMetaType[];
      columns: ColumnType<any>[];
    };
  } = {
    "/admin/role-management": {
      title: "Role Management",
      key_word: "Role",
      url: DynamicRouter("auth", "role"),
      metaData: roleFieldMetaData,
      columns: [
        {
          key: "id",
          dataIndex: "id",
          title: "ID",
          render: (text, record, index) => index + 1,
          width: 50,
        },

        { key: "name", dataIndex: "name", title: "Name" },
        {
          key: "is_super_role",
          dataIndex: "is_super_role",
          title: "Super Role",
          align: "center",
          filters: [
            { text: "Yes", value: true },
            { text: "No", value: false },
          ],
          onFilter: (value, record) => record.is_super_role === value,
          render: (value, record, index) => {
            return value ? "Yes" : "No";
          },
        },
      ],
    },
    "/admin/provider-management": {
      title: "Provider Management",
      key_word: "Provider",
      url: DynamicRouter("project", "provider"),
      metaData: providerFieldMetaData,
      columns: [
        {
          key: "id",
          dataIndex: "id",
          title: "ID",
          render: (text, record, index) => index + 1,
          width: 50,
        },
        {
          key: "company_name",
          dataIndex: "company_name",
          title: "Company Name",
          sorter: (a, b) => a.company_name.localeCompare(b.company_name),
        },
        {
          key: "contact_name",
          dataIndex: "contact_name",
          title: "Contact Name",
          sorter: (a, b) => a.contact_name.localeCompare(b.contact_name),
        },
        {
          key: "contact_phone",
          dataIndex: "contact_phone",
          title: "Contact Phone",
        },
        {
          key: "contact_email",
          dataIndex: "contact_email",
          title: "Contact Email",
          sorter: (a, b) => a.contact_email.localeCompare(b.contact_email),
        },
      ],
    },
    "/admin/user-management": {
      title: "User Management",
      key_word: "User",
      url: DynamicRouter("auth", "user"),
      metaData: userFieldMetaData,
      columns: [
        {
          key: "id",
          dataIndex: "id",
          title: "ID",
          render: (text, record, index) => index + 1,
          width: 50,
        },
        { key: "first_name", dataIndex: "first_name", title: "First Name" },
        { key: "last_name", dataIndex: "last_name", title: "Last Name" },

        { key: "email", dataIndex: "email", title: "Email" },
        { key: "role", dataIndex: "role", title: "Role" },
        {
          key: "organization",
          dataIndex: "organization_name",
          title: "Organization",
          render: (text: any) => text || "-",
        },
        {
          key: "is_superuser",
          dataIndex: "is_superuser",
          title: "Superuser",
          align: "center",
          filters: [
            { text: "Yes", value: true },
            { text: "No", value: false },
          ],
          onFilter: (value, record) => record.is_super_role === value,
          render: (value, record, index) => {
            return value ? "Yes" : "No";
          },
        },
      ],
    },
    "/admin/industry": {
      title: "Industry Management",
      key_word: "Industry",
      url: DynamicRouter("project", "industry"),
      metaData: industryFieldMetaData,
      columns: [
        {
          key: "id",
          dataIndex: "id",
          title: "ID",
          render: (text, record, index) => index + 1,
          width: 50,
        },
        { key: "name", dataIndex: "name", title: "Name" },
        { key: "description", dataIndex: "description", title: "Description" },
      ],
    },
    "/admin/service": {
      title: "Service/Item Management",
      key_word: "Service",
      url: DynamicRouter("project", "service"),
      metaData: serviceFieldMetaData,
      columns: [
        {
          key: "id",
          dataIndex: "id",
          title: "ID",
          render: (text, record, index) => index + 1,
          width: 50,
        },
        { key: "name", dataIndex: "name", title: "Name" },
        { key: "description", dataIndex: "description", title: "Description" },
      ],
    },
    "/admin/businesscycle": {
      title: "Business Cycle Management",
      key_word: "Business Cycle",
      url: DynamicRouter("project", "business-cycle"),
      metaData: businessCycleFieldMetaData,
      columns: [
        {
          key: "id",
          dataIndex: "id",
          title: "ID",
          render: (text, record, index) => index + 1,
          width: 50,
        },
        { key: "name", dataIndex: "name", title: "Name" },
        { key: "description", dataIndex: "description", title: "Description" },
      ],
    },
    "/admin/funtional-area": {
      title: "Functional Area Management",
      key_word: "Functional Area",
      url: DynamicRouter("project", "functional-area"),
      metaData: functionalAreaFieldMetaData,
      columns: [
        {
          key: "id",
          dataIndex: "id",
          title: "ID",
          render: (text, record, index) => index + 1,
          width: 50,
        },
        { key: "name", dataIndex: "name", title: "Name" },
        { key: "description", dataIndex: "description", title: "Description" },
      ],
    },

    "/admin/organization-management": {
      title: "Organization Management",
      key_word: "Organization",
      url: DynamicRouter("auth", "organization"),
      metaData: organizationFieldMetaData,
      columns: [
        {
          key: "id",
          dataIndex: "id",
          title: "ID",
          render: (text, record, index) => index + 1,
          width: 50,
        },
        {
          key: "name",
          dataIndex: "name",
          title: "Organization Name",
        },
        { key: "domain", dataIndex: "domain", title: "Domain" },
      ],
    },
  };

  const urls = useMemo(() => {
    const baseUrl = pathRenderMap[pathname ?? ""]?.url ?? null;
    const urlBusinessCycles = DynamicRouter("project", "business-cycle");
    const detailUrl = record.id ? `${baseUrl}${record.id}/` : baseUrl;

    return {
      base: baseUrl,
      businessCycles: urlBusinessCycles,
      detail: detailUrl,
    };
  }, [pathname, record.id, pathRenderMap]);

  const { data: businessCycles } = useSWR<ApiResponse<any>>(
    urls.businessCycles,
    fetcher
  );

  const {
    data: apiData,
    error,
    isLoading,
    mutate: mutateTable,
  } = useSWR(urls.base, fetcher, {
    revalidateOnFocus: true,
    revalidateOnReconnect: true,
  });

  const searchInData = useCallback(
    (item: { [key: string]: any }) => {
      if (!searchQuery) return true;

      const fieldsToSearch = [
        "name",
        "description",
        "email",
        "role",
        "username",
        "company_name",
        "contact_name",
        "contact_email",
        "contact_phone",
      ];

      return fieldsToSearch.some((field) => {
        if (item[field]) {
          return item[field]
            .toString()
            .toLowerCase()
            .includes(searchQuery.toLowerCase());
        }
        return false;
      });
    },
    [searchQuery]
  );

  const tableData = useMemo(() => {
    if (!apiData) return [];
    if (!apiData.data) return [];
    return Array.isArray(apiData.data) ? apiData.data : [];
  }, [apiData]);

  const filteredData = useMemo(() => {
    if (!tableData.length) return [];
    return tableData.filter(searchInData);
  }, [tableData, searchInData]);

  const dataSoureBusinesCycle = businessCycles?.data.map((item: any) => {
    return {
      value: item.id,
      label: item.name,
    };
  });

  useEffect(() => {
    if (params.get("new") === "True" || params.get("edit") === "True") {
      openDrawer();
    } else {
      closeDrawer();
      form.resetFields();
    }
  }, [params, openDrawer, closeDrawer, form]);

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
    columnWidth: 60,
  };

  const handleFileUpload = async (event: any) => {
    if (event.target?.files) {
      const file = event.target.files[0];

      if (file) {
        const reader = new FileReader();
        reader.onload = async (e) => {
          try {
            const text = e.target?.result;
            const data = text?.toString().split("\n");

            if (data) {
              setPreviewedData(
                data?.map((item: any) =>
                  item.split(",").map((item: any) => item.replaceAll('"', ""))
                )
              );

              setOpenPreview(true);
            }
          } catch (error) {
            notify("Error reading file", "error");
          }
        };
        reader.readAsText(file);
      }
    }
  };

  const openFileDialog = () => {
    if (pathname !== "/admin/funtional-area") {
      // Create a hidden file input on the fly
      const input = document.createElement("input");
      input.type = "file";
      input.accept = ".csv";
      input.onchange = handleFileUpload;
      input.click();
    } else {
      if (functionalAreaParams) {
        const input = document.createElement("input");
        input.type = "file";
        input.accept = ".csv";
        input.onchange = handleFileUpload;
        input.click();
      } else {
        setFunctionalAreaParams(true);
      }
    }
  };

  const handleNewClick = () => {
    form.resetFields(); // Form alanlarını temizle
    router.push(`${pathname}?new=True`); // URL'e new parametresi ekle
    openDrawer(); // Drawer'ı aç
  };

  const handleTechnicalSupport = () => {
    setIsSupportModalOpen(true);
  };

  const handleSupportSubmit = () => {
    supportForm.validateFields().then(values => {
      const supportData = {
        FromPerson: { Uid: "OW42oZYQ" },
        Subject: values.subject,
        Body: values.body,
        Source: 2
      };
      console.log(supportData)

      setLoading(true);
      triggerSupport(supportData, {
        onSuccess: (response) => {
          if (response.statusCode === 200) {
            notify("Support request submitted successfully", "success");
            setIsSupportModalOpen(false);
            supportForm.resetFields();
          } else {
            notify(response.message || "Failed to submit support request", "error");
          }
          setLoading(false);
        },
        onError: () => {
          notify("Error submitting support request", "error");
          setLoading(false);
        }
      });
    });
  };

  const title = () => (
    <Row
      style={{ margin: 0, padding: 0 }}
      justify={"space-between"}
      align={"middle"}
    >
      <Row align={"middle"}>
        <Space>
          {selectedRowKeys.length > 0 && (
            <>
              <Select
                onChange={(value) => {
                  setBulkAction(value);
                }}
                style={{
                  minWidth: 200,
                }}
                options={[
                  {
                    value: "delete",
                    label: "Delete",
                  },
                ]}
              />

              <Button
                type="primary"
                style={{
                  backgroundColor: "#fab31b",
                }}
                onClick={() => {
                  setLoading(true);
                  const table = pathRenderMap[pathname].key_word
                    .toLowerCase()
                    .split(" ")
                    .join("_");

                  const values = {
                    action: bulkAction,
                    table: table,
                    ids: selectedRowKeys,
                  };

                  trigger(values, {
                    onSuccess: (response) => {
                      if (response.statusCode === 200) {
                        notify(response.message, "success");
                        mutateTable();
                        setLoading(false);
                      } else {
                        notify(response.message, "error");
                        setLoading(false);
                      }
                    },
                  });
                }}
              >
                Apply
              </Button>
            </>
          )}
          {![
            "/admin/user-management",
            "/admin/role-management",
            "/admin/questionnaire",
            "/admin/demo",
          ].includes(pathname) ? (
            <Button
              type="dashed"
              style={{ marginLeft: 10 }}
              onClick={openFileDialog}
            >
              CSV UPLOAD
            </Button>
          ) : (
            <></>
          )}
        </Space>
      </Row>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-end",
        }}
      >
        <Input
          width={200}
          placeholder="Search..."
          value={searchQuery}
          onChange={handleSearchChange}
          style={{
            marginRight: 10,
          }}
        />
        <Button
          type="primary"
          onClick={handleNewClick}
          style={{ marginRight: 10 }}
        >
          New {pathRenderMap[pathname ?? ""]?.key_word}
        </Button>
      </div>
    </Row>
  );

  const onRow = (record: any, rowIndex: any) => {
    return {
      onDoubleClick: (event: any) => {
        router.push(`${pathname}?edit=True&id=${record.id}`);
      },
    };
  };

  if (!pathRenderMap[pathname ?? ""]) {
    return <>404</>;
  }

  return (
    <Loader isLoading={loading || isLoading}>
      <div style={{ padding: 20, marginLeft: "60px" }}>
        <Row justify={"space-between"} align={"middle"}>
          <Typography.Text
            style={{
              padding: 0,
              fontWeight: 500,
              fontSize: "14px",
              color: "rgb(0,10,30)",
            }}
          >
            {pathRenderMap[pathname ?? ""]?.title} Table
          </Typography.Text>
          <Space>
            <Button onClick={handleTechnicalSupport}>Technical Support</Button>
          </Space>
        </Row>
        <Divider style={{ margin: "10px 0px" }} />
        <WrapperTable
          rowSelection={rowSelection}
          isLoading={isLoading}
          onRow={onRow}
          data={filteredData}
          title={title}
          columns={pathRenderMap[pathname ?? ""]?.columns ?? []}
        />
        <Drawer
          title={
            record.id
              ? `Update ${pathRenderMap[pathname ?? ""]?.key_word}`
              : `Create ${pathRenderMap[pathname ?? ""]?.key_word}`
          }
          width={720}
          onClose={() => {
            form.resetFields();
            router.push(`${pathname}`);
            closeDrawer();
          }}
          open={isOpen}
          destroyOnClose={true}
        >
          {isOpen && (
            <WrapperCRUDForm
              form={form}
              mutationURL={urls.base}
              metadata={pathRenderMap[pathname ?? ""]?.metaData}
              onFinish={async (response: any) => {
                if (
                  response.statusCode === 200 ||
                  response.statusCode === 201
                ) {
                  notify(response.message, "success");
                  form.resetFields();
                  router.push(`${pathname}`);
                  closeDrawer();
                  await mutateTable();
                } else {
                  notify(response.message, "error");
                }
              }}
              onDeleteFinished={async (response: any) => {
                notify(response.message, "success");
                form.resetFields();
                router.push(`${pathname}`);
                closeDrawer();
                await mutateTable();
              }}
              onCancel={() => {
                form.resetFields();
                router.push(`${pathname}`);
                closeDrawer();
              }}
              buttonText={
                record.id
                  ? `Update ${pathRenderMap[pathname ?? ""]?.key_word}`
                  : `Create ${pathRenderMap[pathname ?? ""]?.key_word}`
              }
            />
          )}
        </Drawer>

        <Modal
          width={800}
          style={{ width: 600 }}
          open={openPreview}
          onCancel={() => {
            setPreviewedData([]);
            setOpenPreview(false);
          }}
          onOk={() => {
            setLoading(true);
            const values = {
              data: previewedData,
              table: pathRenderMap[pathname]?.key_word
                .toLowerCase()
                .split(" ")
                .join("_"),
              business_cycle_id: businessCycle,
            };
            triggerFile(values, {
              onSuccess: (response) => {
                if (response.statusCode === 200) {
                  notify(response.message, "success");
                  setLoading(false);
                  setOpenPreview(false);
                  setPreviewedData([]);
                  setFunctionalAreaParams(false);
                  mutateTable();
                } else {
                  notify(response.message, "error");
                  setLoading(false);
                }
              },
            });
          }}
        >
          <Loader isLoading={loading}>
            <WrapperTable
              height={"600"}
              data={previewedData?.slice(1).map((item1: any) => {
                const obj: any = {};
                previewedData?.[0].forEach((item: any, index: number) => {
                  obj[item] = item1[index];
                });
                return obj;
              })}
              columns={previewedData?.[0]?.map((key: any) => ({
                title: key,
                dataIndex: key,
                key: key,
              }))}
            />
          </Loader>
        </Modal>
      </div>
      <Modal
        onCancel={() => {
          setPreviewedData([]);
          setFunctionalAreaParams(false);
        }}
        open={functionalAreaParams}
        footer={false}
      >
        <Typography.Title level={5}>Select Business ycle</Typography.Title>
        <Select
          style={{
            width: "100%",
          }}
          options={dataSoureBusinesCycle}
          onChange={(value) => {
            setBusinessCycle(value);
          }}
        />
        <Button
          style={{
            margin: 10,
          }}
          onClick={openFileDialog}
        >
          File Upload
        </Button>
      </Modal>

      <Modal
        title="Technical Support"
        open={isSupportModalOpen}
        onCancel={() => {
          setIsSupportModalOpen(false);
          supportForm.resetFields();
        }}
        onOk={handleSupportSubmit}
        confirmLoading={loading}
      >
        <Form form={supportForm} layout="vertical">
          <Form.Item
            name="subject"
            label="Subject"
            rules={[{ required: true, message: 'Please enter a subject' }]}
          >
            <Input placeholder="Enter subject" />
          </Form.Item>
          <Form.Item
            name="body"
            label="Message"
            rules={[{ required: true, message: 'Please enter your message' }]}
          >
            <Input.TextArea rows={4} placeholder="Enter your message" />
          </Form.Item>
        </Form>
      </Modal>
    </Loader>
  );
}
