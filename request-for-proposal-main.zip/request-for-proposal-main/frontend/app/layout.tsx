import AntConfig from "@/components/AntDesign/AntConfig";
import AntLayout from "@/components/AntDesign/AntLayout";
import Notification from "@/components/components/general/Notification";
import "@/components/css/general.css";
import { LoaderProvider } from "@/lib/providers/LoaderContextProvider";
import SWRGeneralProvider from "@/lib/providers/SWRGeneralProvider";
import { AntdRegistry } from "@ant-design/nextjs-registry";
import { SessionProvider } from "next-auth/react";
import "react-toastify/dist/ReactToastify.css";
import { Suspense } from "react";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <AntdRegistry>
          <AntConfig>
            <Notification />
            <LoaderProvider>
              <SessionProvider>
                <SWRGeneralProvider>
                  <Suspense fallback={<div>Loading...</div>}>
                    <AntLayout>{children}</AntLayout>
                  </Suspense>
                </SWRGeneralProvider>
              </SessionProvider>
            </LoaderProvider>
          </AntConfig>
        </AntdRegistry>
      </body>
    </html>
  );
}
